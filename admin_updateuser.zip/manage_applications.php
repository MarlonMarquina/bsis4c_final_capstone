<?php
// FILE: manage_applications.php
include 'conn.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

function e($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

$filter_course_id = intval($_GET['course_filter'] ?? 0);
$where_clause = ($filter_course_id > 0) ? " WHERE c.id = {$filter_course_id} " : "";

// --- POST HANDLERS ---
if (($_POST['action'] ?? null) === 'assign_signatory') {
    $course_id = intval($_POST['course_id'] ?? 0);
    $signatory_id = intval($_POST['signatory_id'] ?? 0);

    if ($course_id > 0 && $signatory_id > 0) {
        $dup = $conn->prepare("SELECT id FROM course_requirements WHERE course_id=? AND signatory_id=?");
        $dup->bind_param("ii", $course_id, $signatory_id);
        $dup->execute();
        if ($dup->get_result()->num_rows == 0) {
            // Admin creates the slot. requirements_configured=0 means signatory hasn't set up yet.
            // Student will NOT see this signatory until signatory configures in requirementssigna.php
            $stmt = $conn->prepare("INSERT INTO course_requirements (course_id, signatory_id, requirements_configured) VALUES (?, ?, 0)");
            $stmt->bind_param("ii", $course_id, $signatory_id); 
            $stmt->execute();
            $stmt->close();
        }
        $dup->close();
    }
    header("Location: manage_applications.php?course_filter={$course_id}");
    exit();
}

if (isset($_GET['delete_assigned'])) {
    $del = intval($_GET['delete_assigned']);
    $redirect_cid = intval($_GET['redirect_cid'] ?? 0);
    if ($del > 0) {
        $stmt = $conn->prepare("DELETE FROM course_requirements WHERE id = ?");
        $stmt->bind_param("i", $del);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: manage_applications.php?course_filter={$redirect_cid}");
    exit();
}

// --- DATA FETCHING ---
$courses_res = $conn->query("SELECT id, course_name FROM courses ORDER BY course_name ASC");

$signatories_res = $conn->query("SELECT id, full_name, signatory_type, department FROM users WHERE role='signatory' ORDER BY full_name ASC");

$assigned_list = [];
$assigned_signatory_ids = []; 

$q = $conn->query("
    SELECT cr.id AS assignment_id, cr.signatory_id, c.id AS course_id, c.course_name, u.full_name, u.signatory_type, u.department
    FROM course_requirements cr
    JOIN users u ON cr.signatory_id = u.id
    JOIN courses c ON cr.course_id = c.id
    {$where_clause}
    ORDER BY c.course_name ASC, u.full_name ASC
");

if ($q) {
    while ($row = $q->fetch_assoc()) {
        $cid = intval($row['course_id']);
        $assigned_list[$cid][] = $row;
        $assigned_signatory_ids[$cid][] = intval($row['signatory_id']);
    }
}

/**
 * FIXED LOGIC:
 * Ginagamit na ngayon ang explode() para suportahan ang maraming department (e.g., "ACT, BSIS").
 */
function canAssignThisSignatory($s, $courseName, $alreadyAssignedIds) {
    // Check kung assigned na
    if (in_array(intval($s['id']), $alreadyAssignedIds)) return false;

    $type = strtolower($s['signatory_type'] ?? '');
    
    // I-explode ang department string (gawing array) para sa multiple departments
    $deptRaw = strtolower(trim($s['department'] ?? ''));
    $deptsArray = array_map('trim', explode(',', $deptRaw)); 
    
    $course = strtolower(trim($courseName));

    // Listahan ng Restricted Roles
    $restricted = ['program head', 'class adviser', 'department head'];
    
    $isRestricted = false;
    foreach($restricted as $r) {
        if(strpos($type, $r) !== false) {
            $isRestricted = true;
            break;
        }
    }

    if ($isRestricted) {
        if (empty($deptRaw)) return false;
        
        // I-check ang bawat department na nakalista sa user
        foreach ($deptsArray as $d) {
            if (empty($d)) continue;
            // Match kung exact match OR kung ang department code ay nasa loob ng course name
            if ($d === $course || strpos($course, $d) !== false) {
                return true;
            }
        }
        return false; 
    }

    // Global roles (Librarian, Registrar, etc.)
    return true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Course Assignment | Smart Clearance</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f4f7f6; margin: 0; padding: 0; }
        .home { position: relative; margin-left: 280px; padding: 30px; min-height: 100vh; display: flex; flex-direction: column; align-items: center; }
        .dashboard-container { width: 100%; max-width: 1100px; background: #fff; border-radius: 12px; padding: 30px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        .dashboard-header { background: linear-gradient(135deg, #2d5016 0%, #1a3409 100%); color: white; padding: 25px; border-radius: 12px; text-align: center; margin-bottom: 25px; width: 100%; max-width: 1100px; }
        .dashboard-header h2 { margin: 0; font-size: 24px; font-weight: 700; }
        .flex-between { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        select { padding: 12px; border-radius: 8px; border: 1px solid #ddd; min-width: 250px; outline: none; }
        .btn { padding: 10px 20px; border-radius: 8px; border: none; cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; transition: 0.3s; }
        .btn-primary { background: #2d5016; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-danger:hover { background: #a71d2a; }
        table { width: 100%; border-collapse: collapse; }
        table th { background: #f8f9fa; color: #2d5016; padding: 15px; text-align: left; border-bottom: 2px solid #eee; font-size: 13px; }
        table td { padding: 15px; border-bottom: 1px solid #eee; font-size: 14px; }
        .course-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; width: 100%; }
        .course-card { background: #fff; border: 1px solid #eee; padding: 25px; border-radius: 12px; text-align: center; cursor: pointer; transition: 0.3s; }
        .course-card:hover { border-color: #2d5016; transform: translateY(-5px); box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .course-card i { font-size: 40px; color: #2d5016; margin-bottom: 15px; }
        .assign-box { background: #f9f9f9; padding: 20px; border-radius: 10px; border: 1px solid #eee; margin-top: 30px; display: flex; justify-content: space-between; align-items: center; }
    </style>
</head>
<body>

<?php include 'sidebar_admin.php'; ?>

<section class="home">
    <div class="dashboard-header">
        <h2>COURSE ASSIGNMENT MANAGEMENT</h2>
    </div>

    <div class="dashboard-container">
        <div class="flex-between">
            <form method="GET">
                <select name="course_filter" onchange="this.form.submit()">
                    <option value="0">--- All Courses ---</option>
                    <?php $courses_res->data_seek(0); while($c = $courses_res->fetch_assoc()): ?>
                        <option value="<?= $c['id'] ?>" <?= $filter_course_id == $c['id'] ? 'selected' : '' ?>><?= e($c['course_name']) ?></option>
                    <?php endwhile; ?>
                </select>
            </form>
            <?php if($filter_course_id > 0): ?>
                <a href="manage_applications.php" class="btn btn-danger"><i class='bx bx-grid-alt'></i> Grid View</a>
            <?php endif; ?>
        </div>

        <?php if($filter_course_id == 0): ?>
            <div class="course-grid">
                <?php $courses_res->data_seek(0); while($course = $courses_res->fetch_assoc()): ?>
                    <div class="course-card" onclick="location.href='?course_filter=<?= $course['id'] ?>'">
                        <i class='bx bx-folder'></i>
                        <div style="font-weight: 700;"><?= e($course['course_name']) ?></div>
                        <div style="font-size: 12px; color: #777; margin-top: 5px;">
                            <?= count($assigned_list[$course['id']] ?? []) ?> Assigned
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <?php 
            $courses_res->data_seek(0);
            while($course = $courses_res->fetch_assoc()):
                if($course['id'] != $filter_course_id) continue;
                $currentCourseName = $course['course_name'];
                $alreadyAssigned = $assigned_signatory_ids[$course['id']] ?? [];
            ?>
                <h3>Selected: <?= e($course['course_name']) ?></h3>
                <table>
                    <thead>
                        <tr>
                            <th>Signatory Name</th>
                            <th>Type</th>
                            <th>Dept</th>
                            <th style="text-align: right;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($assigned_list[$course['id']])): ?>
                            <?php foreach($assigned_list[$course['id']] as $row): ?>
                                <tr>
                                    <td><strong><?= e($row['full_name']) ?></strong></td>
                                    <td><span style="background:#e8f5e9; color:#2d5016; padding:3px 8px; border-radius:5px; font-size:12px;"><?= e($row['signatory_type']) ?></span></td>
                                    <td><?= e($row['department'] ?: 'Global') ?></td>
                                    <td style="text-align: right;">
                                        <a href="?delete_assigned=<?= $row['assignment_id'] ?>&redirect_cid=<?= $course['id'] ?>" class="btn btn-danger" style="padding: 5px 10px;" onclick="return confirm('Remove?')"><i class='bx bx-trash'></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="4" style="text-align:center; padding: 30px; color: #999;">No signatories assigned yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="assign-box">
                    <div style="font-weight: 600; color: #555;">Assign New Signatory</div>
                    <form method="POST" style="display: flex; gap: 10px;">
                        <input type="hidden" name="action" value="assign_signatory">
                        <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
                        <select name="signatory_id" required style="min-width: 300px;">
                            <option value="">-- Choose Signatory --</option>
                            <?php 
                            $signatories_res->data_seek(0);
                            $found = false;
                            while($s = $signatories_res->fetch_assoc()):
                                if(canAssignThisSignatory($s, $currentCourseName, $alreadyAssigned)):
                                    $found = true;
                            ?>
                                <option value="<?= $s['id'] ?>"><?= e($s['full_name']) ?> (<?= e($s['signatory_type']) ?>)</option>
                            <?php endif; endwhile; ?>
                            <?php if(!$found): ?>
                                <option disabled>No available signatories</option>
                            <?php endif; ?>
                        </select>
                        <button type="submit" class="btn btn-primary"><i class='bx bx-plus'></i> Assign to Course</button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
</section>

</body>
</html>