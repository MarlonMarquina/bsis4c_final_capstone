<?php
// FILE: manage_students.php (Complete Full-Length Version - 650+ Lines)
session_start();
include ('conn.php'); 
// --- ADD THIS TO manage_students.php (TOP PART) ---
if (isset($_GET['get_sections_realtime'])) {
    header('Content-Type: application/json');
    $courses = isset($_GET['courses']) ? $_GET['courses'] : [];
    $response = [];

    if (!empty($courses)) {
        foreach ($courses as $c) {
            // Kinukuha natin ang unique Year at Section para sa bawat course
            $stmt = $conn->prepare("SELECT DISTINCT year, section_name FROM sections WHERE course_name = ? ORDER BY year ASC");
            $stmt->bind_param("s", $c);
            $stmt->execute();
            $res = $stmt->get_result();
            
            $sections = [];
            while($row = $res->fetch_assoc()) {
                $sections[] = $row;
            }
            $response[$c] = $sections;
        }
    }
    echo json_encode($response);
    exit;
}
// Security check: Only allow 'admin' role to access
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: login.php");
    exit();
}

// Ensure $conn is loaded from conn.php
if (!isset($conn)) {
    die("Database connection error: \$conn variable not set in conn.php");
}

$msg = '';

/**
 * ------------------------------------------------------------------------------------------
 * DATABASE FUNCTIONS (Logics Unchanged)
 * ------------------------------------------------------------------------------------------
 */

// Function to fetch Courses
function fetchCourses($conn) {
    $result = $conn->query("SELECT id, course_name, duration FROM courses ORDER BY course_name ASC");
    $courses = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $courses[] = $row; 
        }
    }
    return $courses;
}

/**
 * ------------------------------------------------------------------------------------------
 * AJAX HANDLER SECTION (Logics Unchanged)
 * ------------------------------------------------------------------------------------------
 */
if (isset($_GET['ajax_action'])) {
    header('Content-Type: application/json');
    $response = ["success" => false, "message" => "Invalid operation."];
    
    $type = $_REQUEST['type'] ?? '';
    $action = $_REQUEST['action'] ?? '';
    $name = trim($_REQUEST['name'] ?? '');
    $id = $_REQUEST['id'] ?? null;
    
    $name = filter_var($name, FILTER_SANITIZE_STRING); 
    $id = filter_var($id, FILTER_VALIDATE_INT);
    
    try {
        if ($action === 'fetch' && $type === 'course') {
            $stmt = $conn->prepare("SELECT id, course_name AS name, duration FROM courses ORDER BY course_name ASC");
            $stmt->execute();
            $result = $stmt->get_result();
            $output = [];
            while ($row = $result->fetch_assoc()) {
                $c_id = $row['id'];
                $sec_stmt = $conn->prepare("SELECT year, section_name FROM sections WHERE course_id = ? ORDER BY year ASC, section_name ASC");
                $sec_stmt->bind_param("i", $c_id);
                $sec_stmt->execute();
                $sec_res = $sec_stmt->get_result();
                $sections_list = [];
                while($s = $sec_res->fetch_assoc()){
                    $sections_list[] = $s;
                }
                $row['structure'] = $sections_list; 
                $output[] = $row;
                $sec_stmt->close();
            }
            echo json_encode($output);
            exit();
            
        } elseif ($action === 'fetch' && $type === 'section') {
            $courseId = filter_var($_GET['course_id'] ?? null, FILTER_VALIDATE_INT);
            $year = filter_var($_GET['year'] ?? '', FILTER_SANITIZE_STRING);
            
            if ($courseId && $year !== '') {
                $sql = "SELECT id, section_name AS name FROM sections WHERE course_id = ? AND year = ? ORDER BY section_name ASC";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("is", $courseId, $year);
                $stmt->execute();
                $result = $stmt->get_result();
                $output = [];
                while ($row = $result->fetch_assoc()) {
                    $output[] = $row;
                }
                echo json_encode($output);
                exit();
            } else {
                echo json_encode([]); 
                exit();
            }
            
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if ($action === 'add' && $name !== '') {
                if ($type === 'course') {
                    $duration = filter_var($_POST['duration'] ?? 4, FILTER_VALIDATE_INT);
                    $stmt = $conn->prepare("INSERT INTO courses (course_name, duration) VALUES (?, ?)");
                    $stmt->bind_param("si", $name, $duration);
                    if ($stmt->execute()) {
                        $response = ["success" => true, "message" => "Course added."];
                    } else {
                        $response = ["success" => false, "message" => "Error adding course: " . $stmt->error];
                    }
                    $stmt->close();
                } elseif ($type === 'section') {
                    $courseId = filter_var($_POST['course_id'] ?? null, FILTER_VALIDATE_INT);
                    $year = filter_var($_POST['year'] ?? '', FILTER_SANITIZE_STRING);
                    if ($courseId && $year !== '') {
                        $stmt = $conn->prepare("INSERT INTO sections (course_id, year, section_name) VALUES (?, ?, ?)");
                        $stmt->bind_param("iss", $courseId, $year, $name);
                        if ($stmt->execute()) {
                            $response = ["success" => true, "message" => "Section added."];
                        } else {
                            $error_message = strpos($stmt->error, 'Duplicate entry') !== false ? "Section already exists for this Course and Year." : $stmt->error;
                            $response = ["success" => false, "message" => "Error adding section: " . $error_message];
                        }
                        $stmt->close();
                    } else {
                        $response = ["success" => false, "message" => "Missing Course ID or Year for section."];
                    }
                }
            } elseif ($action === 'update' && $type === 'course' && $id && $name !== '') {
                $stmt = $conn->prepare("UPDATE courses SET course_name = ? WHERE id = ?");
                $stmt->bind_param("si", $name, $id);
                if ($stmt->execute()) {
                    $response = ["success" => true, "message" => "Course updated."];
                } else {
                    $response = ["success" => false, "message" => "Error updating course: " . $stmt->error];
                }
                $stmt->close();
                
            } elseif ($action === 'delete' && $id) {
                if ($type === 'course') {
                    $stmt = $conn->prepare("DELETE FROM courses WHERE id = ?");
                    $stmt->bind_param("i", $id);
                    if ($stmt->execute()) {
                        $response = ["success" => true, "message" => "Course deleted."];
                    } else {
                        $response = ["success" => false, "message" => "Error deleting course: " . $stmt->error];
                    }
                    $stmt->close();
                } elseif ($type === 'section') {
                    $stmt = $conn->prepare("DELETE FROM sections WHERE id = ?");
                    $stmt->bind_param("i", $id);
                    if ($stmt->execute()) {
                        $response = ["success" => true, "message" => "Section deleted."];
                    } else {
                        $response = ["success" => false, "message" => "Error deleting section: " . $stmt->error];
                    }
                    $stmt->close();
                }
            }
        }
    } catch (Exception $e) {
        $response = ["success" => false, "message" => "Server exception: " . $e->getMessage()];
    }
    echo json_encode($response);
    exit(); 
}

/**
 * ------------------------------------------------------------------------------------------
 * POST HANDLER: ADD STUDENT (Logics Unchanged)
 * ------------------------------------------------------------------------------------------
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_student_user'])) {
    $username = trim($_POST['username']);
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']); 
    $role = 'student';
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $course = filter_input(INPUT_POST, 'course_name_hidden', FILTER_SANITIZE_STRING) ?? ''; 
    $year = filter_input(INPUT_POST, 'year', FILTER_SANITIZE_STRING) ?? ''; 
    $section = filter_input(INPUT_POST, 'section', FILTER_SANITIZE_STRING) ?? '';
    
    $signatory_type = ''; 
    $department = '';

    $check = $conn->prepare("SELECT username FROM users WHERE username = ? OR email = ?"); 
    $check->bind_param("ss", $username, $email); 
    $check->execute();
    $res = $check->get_result();
    $check->close();

    if ($res->num_rows > 0) {
        $msg = "⚠️ Username or Email already exists!";
    } else {
        $insert = $conn->prepare("INSERT INTO users (username, full_name, email, course, year, section, password, role, signatory_type, department) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if ($insert === false) {
            $msg = "❌ Prepare failed: " . $conn->error;
        } else {
            $insert->bind_param("ssssssssss", $username, $full_name, $email, $course, $year, $section, $password, $role, $signatory_type, $department);
            if ($insert->execute()) {
                $msg = "✅ Student added successfully!";
            } else {
                $msg = "❌ Error adding student: " . $insert->error; 
            }
            $insert->close();
        }
    }
}

$allCourses = fetchCourses($conn); 
$yearOptionsList = ["1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year"]; 
$result = $conn->query("SELECT id, full_name, username, course, year, section FROM users WHERE role='student' ORDER BY full_name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students | Smart Clearance System</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        /* ------------------------------------------------------------------------------------------
            ADAPTED UI STYLING FROM manage_signatories.php
           ------------------------------------------------------------------------------------------ */
        body { font-family: 'Poppins', sans-serif; background: #f4f7f6; margin: 0; padding: 0; }
        
        .home { 
            position: relative; 
            margin-left: 280px; 
            padding: 30px; 
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            transition: all 0.5s ease;
        }
        .sidebar.close ~ .home { margin-left: 88px; width: calc(100% - 88px); }

        .dashboard-container { 
            width: 100%; 
            max-width: 1200px;
            background: #fff; 
            border-radius: 15px; 
            padding: 35px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.1); 
            box-sizing: border-box;
        }

        .dashboard-header { 
            background: linear-gradient(135deg, #2d5016 0%, #1a3409 100%);
            color: white; 
            padding: 30px; 
            border-radius: 12px; 
            text-align: center; 
            margin-bottom: 30px;
            width: 100%;
            max-width: 1200px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .dashboard-header h2 { margin: 0; font-size: 28px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; }

        /* Tables */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; border-radius: 10px; overflow: hidden; }
        table th { 
            background: linear-gradient(135deg, #2d5016 0%, #1a3409 100%);
            color: white; padding: 18px; text-align: left; text-transform: uppercase; font-size: 13px; letter-spacing: 0.5px;
        }
        table td { padding: 15px; border-bottom: 1px solid #eee; font-size: 14px; color: #444; }
        table tr:hover { background-color: #f1f8f1; }

        /* Buttons */
        .btn { 
            padding: 10px 18px; 
            border-radius: 8px; 
            border: none; 
            cursor: pointer; 
            text-decoration: none; 
            font-size: 14px; 
            font-weight: 600; 
            display: inline-flex; 
            align-items: center; 
            gap: 8px; 
            transition: all 0.3s ease; 
        }
        .add-btn { 
            background: linear-gradient(135deg, #2d5016 0%, #1a3409 100%); 
            color: white; 
            box-shadow: 0 4px 10px rgba(45, 80, 22, 0.3);
        }
        .add-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(45, 80, 22, 0.4); }
        
        .btn-edit { background-color: #4CAF50; color: white; }
        .btn-delete { background-color: #e74c3c; color: white; }
        .btn-delete:hover { background-color: #c0392b; transform: scale(1.05); }
        
        .import-btn { background: #3498db; color: white; }
        .import-btn:hover { background: #2980b9; transform: translateY(-2px); }

        /* Modals */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.6); backdrop-filter: blur(5px); }
        .modal-content { 
            background-color: #fff; 
            margin: 5% auto; 
            padding: 30px; 
            width: 90%; 
            max-width: 500px; 
            border-radius: 15px; 
            box-shadow: 0 15px 40px rgba(0,0,0,0.2); 
            animation: slideDown 0.4s ease;
        }
        @keyframes slideDown { from { transform: translateY(-50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        
        .close-btn { color: #888; float: right; font-size: 30px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .close-btn:hover { color: #e74c3c; }
        
        .modal-content h3 { color: #2d5016; margin-bottom: 20px; font-size: 22px; border-bottom: 2px solid #f0f0f0; padding-bottom: 10px; }
        .modal-content label { display: block; margin: 12px 0 6px; font-weight: 600; color: #555; }
        .modal-content input, .modal-content select { width: 100%; padding: 12px; border: 2px solid #eee; border-radius: 8px; box-sizing: border-box; font-family: inherit; }
        .modal-content input:focus, .modal-content select:focus { border-color: #2d5016; outline: none; }
        
        /* Hierarchy Section */
        .hierarchy-details { display: none; background: #f9f9f9; padding: 15px; border-radius: 10px; margin-top: 10px; border-left: 5px solid #2d5016; }
        .year-label { font-weight: bold; color: #2d5016; text-decoration: none; font-size: 14px; }
        .section-pill { background: #2d5016; color: white; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 500; }
        .view-info-btn { color: #2d5016; font-weight: 600; background: none; border: none; cursor: pointer; text-decoration: underline; padding: 10px 0; }

        .message { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: 500; border-left: 5px solid; }
        .message.success { background: #e8f5e9; color: #2e7d32; border-color: #2e7d32; }
        .message.error { background: #ffebee; color: #c62828; border-color: #c62828; }
        .disabled-field { background-color: #f9f9f9 !important; border-color: #eee !important; color: #bbb !important; }
    </style>
</head>
<body>
    <?php 
    $admin_username = $_SESSION['username'];
    $stmt = $conn->prepare("SELECT full_name FROM users WHERE username = ? AND role = 'admin'");
    $stmt->bind_param("s", $admin_username);
    $stmt->execute();
    $admin_data = $stmt->get_result()->fetch_assoc();
    $signatoryFullName = !empty($admin_data['full_name']) ? $admin_data['full_name'] : $admin_username;
    $userRole = "Administrator"; 
    include 'sidebar_admin.php'; 
    ?>

    <section class="home">
        <div class="dashboard-header">
            <h2><i class='bx bxs-group'></i> Manage Students</h2>
        </div>

        <div class="dashboard-container">
            <?php if (!empty($msg)): ?>
                <div class="message <?= (strpos($msg, 'Error') !== false || strpos($msg, '⚠️') !== false || strpos($msg, '❌') !== false) ? 'error' : 'success' ?>">
                    <?= htmlspecialchars($msg) ?>
                </div>
            <?php endif; ?>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; flex-wrap: wrap; gap: 15px;">
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    <a href="#" class="btn add-btn" style="background: #3498db;" onclick="openModal('manageCoursesModal'); loadCourses(); return false;"><i class='bx bx-book-bookmark'></i> Manage Courses</a>
                    <a href="#" class="btn add-btn" style="background: #f39c12;" onclick="openModal('manageSectionsUnifiedModal'); return false;"><i class='bx bx-category'></i> Manage Sections</a>
                    <a href="#" class="btn add-btn" onclick="openModal('addStudentModal'); return false;"><i class='bx bx-user-plus'></i> Add Student</a>
                </div>
                <div>
                    <a href="student_import_form.php" class="btn import-btn"><i class='bx bx-cloud-upload'></i> Import Students (Excel)</a>
                </div>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Full Name</th>
                        <th>Username</th>
                        <th>Course</th>
                        <th>Year</th>
                        <th>Section</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td style='font-weight:600;'> " . htmlspecialchars($row['full_name']) . "</td>
                                <td>" . htmlspecialchars($row['username']) . "</td>
                                <td>" . htmlspecialchars($row['course']) . "</td>
                                <td>" . htmlspecialchars($row['year']) . "</td>
                                <td><span style='background:#f0f0f0; padding:4px 10px; border-radius:15px; font-size:12px;'>" . htmlspecialchars($row['section']) . "</span></td>
                                <td style='text-align:center;'>
                                    <a href='edit_students.php?id={$row['id']}' class='btn btn-edit'><i class='bx bx-edit'></i></a>
                                    <a href='delete_student.php?id={$row['id']}' class='btn btn-delete' onclick='return confirm(\"Are you sure?\")'><i class='bx bx-trash'></i></a>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' style='text-align:center; padding: 40px; color:#999;'>No students found in the database.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </section>

    <div id="addStudentModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('addStudentModal')">&times;</span>
            <h3><i class='bx bx-user-plus'></i> Add New Student</h3>
            <form method="POST">
                <label>Full Name:</label>
                <input type="text" name="full_name" placeholder="Enter Full Name" required>
                <label>Username:</label>
                <input type="text" name="username" placeholder="2024-XXXX" required>
                <label>Email Address:</label>
                <input type="email" name="email" placeholder="email@domain.com" required>
                <label>Password:</label>
                <input type="password" name="password" placeholder="••••••••" required>
                
                <label>Course:</label>
                <select name="course_id_selector" id="as_course" onchange="handleStudentFlow('course')" required>
                    <option value="">Select Course</option>
                </select>
                <input type="hidden" name="course_name_hidden" id="as_course_hidden">

                <label>Year Level:</label>
                <select name="year" id="as_year" class="disabled-field" disabled onchange="handleStudentFlow('year')" required>
                    <option value="">Select Course First</option>
                </select>

                <label>Section:</label>
                <select name="section" id="as_section" class="disabled-field" disabled required>
                    <option value="">Select Year First</option>
                </select>

                <div style="margin-top:20px; display:flex; gap:10px;">
                    <button type="submit" name="add_student_user" class="btn add-btn" style="flex:2; justify-content:center;">Register Student</button>
                    <button type="button" class="btn" style="background:#eee; color:#333; flex:1; justify-content:center;" onclick="closeModal('addStudentModal')">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <div id="manageSectionsUnifiedModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal('manageSectionsUnifiedModal')">&times;</span>
            <h3><i class='bx bx-category'></i> Manage Sections</h3>
            <label>1. Select Course:</label>
            <select id="ms_course" onchange="handleSectionFlow('course')">
                <option value="">-- Select Course --</option>
            </select>

            <label>2. Select Year:</label>
            <select id="ms_year" class="disabled-field" disabled onchange="handleSectionFlow('year')">
                <option value="">-- Select Course First --</option>
            </select>

            <div id="ms_input_area" style="display:none; margin-top:20px; border-top:1px solid #eee; padding-top:20px;">
                <label>3. Current Sections:</label>
                <div id="ms_list" style="max-height:150px; overflow-y:auto; margin-bottom:15px; border:1px solid #eee; padding:10px; border-radius:10px; background:#fafafa;"></div>
                
                <label>4. Add New Section:</label>
                <div style="display:flex; gap:8px;">
                    <input type="text" id="ms_new_name" placeholder="E.g., Section A" style="margin-bottom:0;">
                    <button type="button" class="btn add-btn" onclick="submitNewSection()">Add</button>
                </div>
            </div>
            <button type="button" class="btn" style="background:#eee; color:#333; width:100%; margin-top:20px;" onclick="closeModal('manageSectionsUnifiedModal')">Close</button>
        </div>
    </div>

    <div id="manageCoursesModal" class="modal">
        <div class="modal-content" style="max-width: 550px;">
            <span class="close-btn" onclick="closeModal('manageCoursesModal')">&times;</span>
            <h3><i class='bx bx-book-bookmark'></i> Manage Courses</h3>
            <div style="background:#fcfcfc; padding:15px; border-radius:10px; border:1px solid #eee; margin-bottom:20px;">
                <label>New Course Name:</label>
                <input type="text" id="c_name" placeholder="E.g., BSIS" required>
                <label>Duration (Years):</label>
                <select id="c_duration">
                    <option value="1">1 Year</option>
                    <option value="2">2 Years</option>
                    <option value="3">3 Years</option>
                    <option value="4" selected>4 Years</option>
                    <option value="5">5 Years</option>
                </select>
                <button type="button" class="btn add-btn" style="width:100%; margin-top:15px; justify-content:center;" onclick="submitNewCourse()">Save New Course</button>
            </div>
            
            <p style="text-align:left; font-weight:700; color:#2d5016; margin-bottom:10px;">Existing Courses:</p>
            <div id="c_list" style="max-height:300px; overflow-y:auto; padding-right:5px;"></div>
            <button type="button" class="btn" style="background:#eee; color:#333; width:100%; margin-top:20px;" onclick="closeModal('manageCoursesModal')">Close</button>
        </div>
    </div>

    <script>
    function syncAllDropdowns() {
        fetch('manage_students.php?ajax_action=1&type=course&action=fetch')
        .then(r => r.json()).then(data => {
            const dropdowns = ['as_course', 'ms_course'];
            dropdowns.forEach(id => {
                const el = document.getElementById(id);
                if(!el) return;
                const saved = el.value;
                el.innerHTML = '<option value="">Select Course</option>';
                data.forEach(c => {
                    let opt = new Option(c.name, c.id);
                    opt.dataset.duration = c.duration;
                    el.add(opt);
                });
                el.value = saved;
            });
        });
    }

    function handleStudentFlow(step) {
        const c = document.getElementById('as_course');
        const y = document.getElementById('as_year');
        const s = document.getElementById('as_section');
        const hidden = document.getElementById('as_course_hidden');

        if(step === 'course') {
            if(!c.value) {
                y.disabled = s.disabled = true;
                y.classList.add('disabled-field'); s.classList.add('disabled-field');
                return;
            }
            hidden.value = c.options[c.selectedIndex].text;
            const dur = parseInt(c.options[c.selectedIndex].dataset.duration);
            y.innerHTML = '<option value="">Select Year</option>';
            const labels = ["1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year"];
            for(let i=0; i<dur; i++) y.add(new Option(labels[i], labels[i]));
            y.disabled = false; y.classList.remove('disabled-field');
            s.disabled = true; s.classList.add('disabled-field');
        } 
        else if(step === 'year') {
            if(!y.value) return;
            fetch(`manage_students.php?ajax_action=1&type=section&action=fetch&course_id=${c.value}&year=${y.value}`)
            .then(r => r.json()).then(data => {
                s.innerHTML = '<option value="">Select Section</option>';
                data.forEach(item => s.add(new Option(item.name, item.name)));
                s.disabled = false; s.classList.remove('disabled-field');
            });
        }
    }

    function handleSectionFlow(step) {
        const c = document.getElementById('ms_course');
        const y = document.getElementById('ms_year');
        const area = document.getElementById('ms_input_area');

        if(step === 'course') {
            if(!c.value) {
                y.disabled = true; y.classList.add('disabled-field');
                area.style.display = 'none'; return;
            }
            const dur = parseInt(c.options[c.selectedIndex].dataset.duration);
            y.innerHTML = '<option value="">Select Year</option>';
            const labels = ["1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year"];
            for(let i=0; i<dur; i++) y.add(new Option(labels[i], labels[i]));
            y.disabled = false; y.classList.remove('disabled-field');
            area.style.display = 'none';
        }
        else if(step === 'year') {
            if(!y.value) { area.style.display = 'none'; return; }
            area.style.display = 'block';
            refreshSectionList(c.value, y.value);
        }
    }

    function refreshSectionList(cid, year) {
        fetch(`manage_students.php?ajax_action=1&type=section&action=fetch&course_id=${cid}&year=${year}`)
        .then(r => r.json()).then(data => {
            const container = document.getElementById('ms_list');
            container.innerHTML = data.map(s => `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; background:#fff; padding:8px 12px; border-radius:8px; border:1px solid #eee;">
                    <span style="font-weight:500;">${s.name}</span>
                    <button type="button" onclick="deleteSectionItem(${s.id})" style="color:#e74c3c; background:none; border:none; cursor:pointer; font-size:18px;"><i class='bx bx-trash'></i></button>
                </div>
            `).join('') || '<small style="color:#999;">No sections created yet.</small>';
        });
    }

    function submitNewSection() {
        const cid = document.getElementById('ms_course').value;
        const year = document.getElementById('ms_year').value;
        const name = document.getElementById('ms_new_name').value.trim();
        if(!name) return alert("Enter section name");
        let fd = new FormData();
        fd.append('course_id', cid); fd.append('year', year); fd.append('name', name);
        fetch('manage_students.php?ajax_action=1&type=section&action=add', { method: 'POST', body: fd })
        .then(r => r.json()).then(res => {
            if(res.success) {
                document.getElementById('ms_new_name').value = '';
                refreshSectionList(cid, year);
            } else alert(res.message);
        });
    }

    function submitNewCourse() {
        const name = document.getElementById('c_name').value.trim();
        const dur = document.getElementById('c_duration').value;
        if(!name) return alert("Name is required");
        let fd = new FormData();
        fd.append('name', name); fd.append('duration', dur);
        fetch('manage_students.php?ajax_action=1&type=course&action=add', { method: 'POST', body: fd })
        .then(r => r.json()).then(res => {
            if(res.success) {
                document.getElementById('c_name').value = '';
                loadCourses(); syncAllDropdowns();
            } else alert(res.message);
        });
    }

    function loadCourses() {
        fetch('manage_students.php?ajax_action=1&type=course&action=fetch')
        .then(r => r.json()).then(data => {
            document.getElementById('c_list').innerHTML = data.map(c => {
                const yearsMap = {};
                c.structure.forEach(item => {
                    if(!yearsMap[item.year]) yearsMap[item.year] = [];
                    yearsMap[item.year].push(item.section_name);
                });
                let hierarchyHtml = '';
                for (const yr in yearsMap) {
                    hierarchyHtml += `
                        <div class="year-block" style="margin-bottom:12px;">
                            <span class="year-label">${yr}</span>
                            <div class="section-pills" style="display:flex; flex-wrap:wrap; gap:6px; margin-top:5px;">
                                ${yearsMap[yr].map(sec => `<span class="section-pill">${sec}</span>`).join('')}
                            </div>
                        </div>
                    `;
                }
                if(hierarchyHtml === '') hierarchyHtml = '<i style="color:gray; font-size:12px;">No sections mapped.</i>';
                return `
                <div class="list-manager-item" style="border:1px solid #eee; margin-bottom:10px; border-radius:10px; padding:15px;">
                    <div class="list-header" style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-weight:700; color:#333;">${c.name} <small style="color:#888;">(${c.duration} Yrs)</small></span>
                        <button onclick="deleteCourseItem(${c.id})" style="color:#e74c3c; background:none; border:none; cursor:pointer;"><i class='bx bx-trash' style='font-size:20px;'></i></button>
                    </div>
                    <button class="view-info-btn" onclick="toggleHierarchy(this)">View Structure <i class='bx bx-chevron-down'></i></button>
                    <div class="hierarchy-details">${hierarchyHtml}</div>
                </div>
                `;
            }).join('');
        });
    }

    function toggleHierarchy(btn) {
        const details = btn.nextElementSibling;
        const icon = btn.querySelector('i');
        if(details.style.display === 'block') {
            details.style.display = 'none';
            btn.innerHTML = "View Structure <i class='bx bx-chevron-down'></i>";
        } else {
            details.style.display = 'block';
            btn.innerHTML = "Hide Structure <i class='bx bx-chevron-up'></i>";
        }
    }

    function deleteCourseItem(id) {
        if(!confirm("Are you sure you want to delete this course? All associated data will be removed.")) return;
        let fd = new FormData(); fd.append('id', id);
        fetch('manage_students.php?ajax_action=1&type=course&action=delete', { method: 'POST', body: fd })
        .then(() => { loadCourses(); syncAllDropdowns(); });
    }

    function deleteSectionItem(id) {
        if(!confirm("Delete this section?")) return;
        let fd = new FormData(); fd.append('id', id);
        fetch('manage_students.php?ajax_action=1&type=section&action=delete', { method: 'POST', body: fd })
        .then(() => {
            refreshSectionList(document.getElementById('ms_course').value, document.getElementById('ms_year').value);
        });
    }

    function openModal(id) { document.getElementById(id).style.display = 'block'; syncAllDropdowns(); }
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }
    window.onclick = function(event) { if (event.target.className === 'modal') { event.target.style.display = 'none'; } }
    </script>
</body>
</html>