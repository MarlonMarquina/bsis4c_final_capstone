<?php
// FILE: admin_verify_action.php
// Handles final clearance approval by admin
session_start();
include 'conn.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$action = $_GET['action'] ?? '';
$student_id = $_GET['id'] ?? '';

if ($action === 'approve' && !empty($student_id)) {
    // Verify student exists and is eligible for approval
    $check_stmt = $conn->prepare("
        SELECT username, full_name, final_clearance_status 
        FROM users 
        WHERE username = ? AND role = 'student'
    ");
    $check_stmt->bind_param("s", $student_id);
    $check_stmt->execute();
    $student = $check_stmt->get_result()->fetch_assoc();
    $check_stmt->close();
    
    if (!$student) {
        header("Location: admin_users.php?msg=" . urlencode("❌ Student not found"));
        exit();
    }
    
    if ($student['final_clearance_status'] !== 'pending') {
        header("Location: admin_users.php?msg=" . urlencode("⚠️ Student has not requested verification yet"));
        exit();
    }
    
    // Double-check all requirements are cleared
    $course_check = $conn->prepare("SELECT course FROM users WHERE username = ?");
    $course_check->bind_param("s", $student_id);
    $course_check->execute();
    $course_result = $course_check->get_result()->fetch_assoc();
    $student_course = $course_result['course'];
    $course_check->close();
    
    // Get required signatories
    $req_stmt = $conn->prepare("
        SELECT u.username as sig_user
        FROM course_requirements cr
        JOIN users u ON cr.signatory_id = u.id
        WHERE cr.course_id = (SELECT id FROM courses WHERE course_name = ? LIMIT 1)
        AND u.status = 'active'
    ");
    $req_stmt->bind_param("s", $student_course);
    $req_stmt->execute();
    $req_result = $req_stmt->get_result();
    
    $all_cleared = true;
    while ($req = $req_result->fetch_assoc()) {
        $check_app = $conn->prepare("
            SELECT status 
            FROM applications 
            WHERE username = ? AND signatory = ? AND status = 'Approved'
        ");
        $check_app->bind_param("ss", $student_id, $req['sig_user']);
        $check_app->execute();
        
        if ($check_app->get_result()->num_rows === 0) {
            $all_cleared = false;
            $check_app->close();
            break;
        }
        $check_app->close();
    }
    $req_stmt->close();
    
    if (!$all_cleared) {
        header("Location: admin_users.php?msg=" . urlencode("❌ Student has incomplete requirements. Cannot approve."));
        exit();
    }
    
    // All checks passed - approve the clearance
    $approve_stmt = $conn->prepare("
        UPDATE users 
        SET admin_approved = 1, 
            final_clearance_status = 'cleared'
        WHERE username = ?
    ");
    $approve_stmt->bind_param("s", $student_id);
    
    if ($approve_stmt->execute()) {
        $approve_stmt->close();
        
        // Create notification for student
        $notification_msg = "🎉 Congratulations! Your final clearance has been approved by the admin. You can now generate your clearance form.";
        $notif_stmt = $conn->prepare("
            INSERT INTO notifications (username, message, type, created_at, is_read) 
            VALUES (?, ?, 'success', NOW(), 0)
        ");
        $notif_stmt->bind_param("ss", $student_id, $notification_msg);
        $notif_stmt->execute();
        $notif_stmt->close();
        
        $conn->close();
        header("Location: admin_users.php?msg=" . urlencode("✅ Final clearance approved for " . $student['full_name']));
        exit();
    } else {
        $approve_stmt->close();
        $conn->close();
        header("Location: admin_users.php?msg=" . urlencode("❌ Error approving clearance. Please try again."));
        exit();
    }
} else {
    $conn->close();
    header("Location: admin_users.php?msg=" . urlencode("❌ Invalid action"));
    exit();
}
?>