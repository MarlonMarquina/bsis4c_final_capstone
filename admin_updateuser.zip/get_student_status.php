<?php
// FILE: get_student_status.php
// Returns student clearance status and requirements for admin verification modal
include 'conn.php';
header('Content-Type: application/json');

$studentId = $_GET['id'] ?? '';

if (empty($studentId)) {
    echo json_encode(['error' => 'Student ID is required']);
    exit;
}

// Get student info
$stmt = $conn->prepare("
    SELECT full_name, course, year, section, final_clearance_status, admin_approved 
    FROM users 
    WHERE username = ? AND role = 'student'
");
$stmt->bind_param("s", $studentId);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$student) {
    echo json_encode(['error' => 'Student not found']);
    exit;
}

// Map clearance status for display
$clearance_class = 'status-not-requested';
$display_status = 'Not Requested';

if ($student['admin_approved'] == 1) {
    $clearance_class = 'status-approved';
    $display_status = 'Approved';
} elseif ($student['final_clearance_status'] == 'pending') {
    $clearance_class = 'status-under-review';
    $display_status = 'Under Review';
}

// Get required signatories and check their status
$requirements = [];
$course = $student['course'];

$req_stmt = $conn->prepare("
    SELECT u.signatory_type, u.username as sig_user
    FROM course_requirements cr
    JOIN users u ON cr.signatory_id = u.id
    WHERE cr.course_id = (SELECT id FROM courses WHERE course_name = ? LIMIT 1)
    AND u.status = 'active'
    ORDER BY u.signatory_type ASC
");
$req_stmt->bind_param("s", $course);
$req_stmt->execute();
$res = $req_stmt->get_result();

while ($row = $res->fetch_assoc()) {
    // Check if this signatory has approved the student
    $check_app = $conn->prepare("
        SELECT status 
        FROM applications 
        WHERE username = ? AND signatory = ? AND status = 'Approved'
    ");
    $check_app->bind_param("ss", $studentId, $row['sig_user']);
    $check_app->execute();
    $is_cleared = $check_app->get_result()->num_rows > 0;
    $check_app->close();

    $requirements[] = [
        'office' => $row['signatory_type'],
        'status' => $is_cleared ? 'cleared' : 'pending'
    ];
}
$req_stmt->close();

$conn->close();

// Return JSON response
echo json_encode([
    'student_info' => [
        'full_name' => $student['full_name'],
        'course' => $student['course'],
        'year' => $student['year'],
        'section' => $student['section'],
        'clearance_status' => $display_status,
        'clearance_class' => $clearance_class,
        'admin_approved' => $student['admin_approved']
    ],
    'requirements' => $requirements
]);
?>