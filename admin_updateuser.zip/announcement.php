<?php
session_start();
if (!isset($_SESSION['role']) || ($_SESSION['role'] != "signatory" && $_SESSION['role'] != "admin")) {
    header("Location: login.php");
    exit();
}

include('conn.php');

$username = $_SESSION['username'];

// --- FIX: Fetch Signatory Info para sa Sidebar ---
$sigInfoStmt = $conn->prepare("SELECT full_name FROM users WHERE username = ? LIMIT 1");
$sigInfoStmt->bind_param("s", $username);
$sigInfoStmt->execute();
$sigResult = $sigInfoStmt->get_result();
$signatoryData = $sigResult->fetch_assoc();

// Ito ang variable na hinahanap ng sidebar_signa.php
$signatoryFullName = $signatoryData['full_name'] ?? $username; 
$sigInfoStmt->close();

// Handle new post
if (isset($_POST['post'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $stmt = $conn->prepare("INSERT INTO announcements (title, content, created_by) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $content, $username);
    $stmt->execute();
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM announcements WHERE id=$id");
    header("Location: announcements.php"); // Refresh para malinis ang URL
    exit();
}

$result = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Announcements | BPC Clearance</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="styles.css">
    <style>
        .home { padding:25px; transition: all 0.5s ease; }
        .container {
            background:white; padding:25px; border-radius:10px;
            box-shadow:0 4px 10px rgba(0,0,0,0.1);
            width:90%; margin:20px auto;
        }
        h2 { color:darkgreen; margin-bottom:15px; }
        form { display:flex; flex-direction:column; gap:10px; }
        input[type=text], textarea {
            width:100%; padding:10px; border:1px solid #ccc; border-radius:6px;
            font-family:'Poppins',sans-serif;
        }
        textarea { resize:none; height:100px; }
        button {
            background:darkgreen; color:white; border:none; padding:10px;
            border-radius:6px; cursor:pointer; transition:0.3s;
        }
        button:hover { background:#0b4e12; }
        .announcement {
            border:1px solid #ddd; border-radius:8px; padding:15px;
            margin-top:15px; background:#f9f9f9;
        }
        .announcement h3 { margin:0; color:#333; }
        .announcement small { color:#666; font-size:13px; }
        .delete-btn { color:red; text-decoration:none; float:right; font-size:14px; }
        .delete-btn:hover { text-decoration:underline; }
    </style>
</head>
<body>
  
<?php include 'sidebar_signa.php'; ?>

<section class="home">
    <div class="container">
        <h2>Create Announcement</h2>
        <form method="POST">
            <input type="text" name="title" placeholder="Announcement Title" required>
            <textarea name="content" placeholder="Write your announcement..." required></textarea>
            <button type="submit" name="post">Post Announcement</button>
        </form>

        <h2 style="margin-top:30px;">Recent Announcements</h2>
        <?php if ($result && $result->num_rows > 0): while ($row = $result->fetch_assoc()): ?>
            <div class="announcement">
                <h3><?= htmlspecialchars($row['title']) ?></h3>
                <small>Posted by <?= htmlspecialchars($row['created_by']) ?> • <?= $row['created_at'] ?></small>
                <p><?= nl2br(htmlspecialchars($row['content'])) ?></p>
                <?php if ($row['created_by'] == $username): ?>
                    <a href="?delete=<?= $row['id'] ?>" class="delete-btn" onclick="return confirm('Delete this announcement?')">Delete</a>
                <?php endif; ?>
            </div>
        <?php endwhile; else: ?>
            <p>No announcements posted yet.</p>
        <?php endif; ?>
    </div>
</section>

<script>
    document.addEventListener("DOMContentLoaded", () => {
        // Hanapin ang elements
        const body = document.querySelector('body'),
              sidebar = document.querySelector('nav'), // Siguraduhin na 'nav' ang tag ng sidebar mo
              toggle = document.querySelector(".toggle"); 

        // Toggle Logic
        if(toggle && sidebar) {
            toggle.addEventListener("click" , () => {
                sidebar.classList.toggle("close");
            });
        }
    });

    function confirmLogout(){
        if(confirm("Are you sure you want to logout?"))
            window.location.href='logout.php';
    }
</script>

</body>
</html>