<?php
// FILE: student_history.php  
// UPDATED: Dynamic signatories in print template — only shows assigned ones
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != "student") {
    header("Location: login.php");
    exit();
}

include 'conn.php';
date_default_timezone_set('Asia/Manila');

$username = $_SESSION['username'];

// ==== HELPER FUNCTION to fetch student profile ====
function fetchStudentProfile($conn, $username) {
    $res = $conn->prepare("SELECT full_name, course, year, section, contact, email, final_clearance_status, admin_approved FROM users WHERE username = ? LIMIT 1");
    $res->bind_param("s", $username);
    $res->execute();
    $rres = $res->get_result();
    $data = [
        'full_name' => '',
        'course' => '',
        'year' => '',
        'section' => '',
        'contact' => '',
        'email' => '',
        'final_clearance_status' => 'not_requested',
        'admin_approved' => 0
    ];
    if ($rres && $rres->num_rows > 0) {
        $row = $rres->fetch_assoc();
        $data = [
            'full_name' => $row['full_name'] ?? '',
            'course' => $row['course'] ?? '',
            'year' => $row['year'] ?? '',
            'section' => $row['section'] ?? '',
            'contact' => $row['contact'] ?? '',
            'email' => $row['email'] ?? '',
            'final_clearance_status' => $row['final_clearance_status'] ?? 'pending',
            'admin_approved' => $row['admin_approved'] ?? 0
        ];
    }
    $res->close();
    return $data;
}

// ==== 1. Initial fetch of student profile ====
$student_data = fetchStudentProfile($conn, $username);
$full_name = $student_data['full_name'];
$user_course = $student_data['course'];
$user_year = $student_data['year'];
$user_section = $student_data['section'];
$user_contact = $student_data['contact'];
$user_email = $student_data['email'];
$final_clearance_status = $student_data['final_clearance_status'];
$admin_approved = $student_data['admin_approved'];

// Get current academic year and semester
$current_year = date('Y');
$next_year = $current_year + 1;
$academic_year = $current_year . '-' . $next_year;
$current_month = date('n');
$semester = ($current_month >= 6 && $current_month <= 10) ? '1st Semester' : '2nd Semester';

function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// === 2. Handle Post Actions ===
if (isset($_POST['request_verification'])) {
    $status_check = $conn->prepare("SELECT final_clearance_status FROM users WHERE username = ? LIMIT 1");
    $status_check->bind_param("s", $username);
    $status_check->execute();
    $status_result = $status_check->get_result();
    $current_status = $status_result->fetch_assoc()['final_clearance_status'] ?? 'pending';
    $status_check->close();
    
    if ($current_status === 'not_requested') {
        $course_check = $conn->prepare("SELECT course FROM users WHERE username = ?");
        $course_check->bind_param("s", $username);
        $course_check->execute();
        $course_result = $course_check->get_result()->fetch_assoc();
        $check_course = $course_result['course'];
        $course_check->close();
        
        $req_count_stmt = $conn->prepare("
            SELECT COUNT(*) as total
            FROM course_requirements cr
            JOIN users u ON cr.signatory_id = u.id
            WHERE cr.course_id = (SELECT id FROM courses WHERE course_name = ? LIMIT 1)
            AND u.status = 'active'
        ");
        $req_count_stmt->bind_param("s", $check_course);
        $req_count_stmt->execute();
        $total_req = $req_count_stmt->get_result()->fetch_assoc()['total'];
        $req_count_stmt->close();
        
        $app_count_stmt = $conn->prepare("
            SELECT COUNT(DISTINCT signatory) as approved
            FROM applications
            WHERE username = ? AND status = 'Approved'
        ");
        $app_count_stmt->bind_param("s", $username);
        $app_count_stmt->execute();
        $approved_req = $app_count_stmt->get_result()->fetch_assoc()['approved'];
        $app_count_stmt->close();
        
        if ($approved_req >= $total_req && $total_req > 0) {
            $upd = $conn->prepare("UPDATE users SET final_clearance_status = 'pending' WHERE username = ?");
            $upd->bind_param("s", $username);
            
            if ($upd->execute()) {
                $upd->close();
                $student_data = fetchStudentProfile($conn, $username);
                $final_clearance_status = $student_data['final_clearance_status'];
                
                $admin_query = $conn->query("SELECT username FROM users WHERE role = 'admin' LIMIT 1");
                $admin_user = $admin_query->fetch_assoc()['username'] ?? 'adminkaren';
                
                $notification_msg = "Student " . $full_name . " (" . $username . ") has requested final clearance verification.";
                $notif_stmt = $conn->prepare("INSERT INTO notifications (username, message, type, created_at, is_read) VALUES (?, ?, 'info', NOW(), 0)");
                $notif_stmt->bind_param("ss", $admin_user, $notification_msg);
                $notif_stmt->execute();
                $notif_stmt->close();
                
                header("Location: student_history.php?msg=" . urlencode("✅ Verification request submitted successfully!"));
                exit();
            }
        } else {
            header("Location: student_history.php?msg=" . urlencode("⚠️ Complete all signatory requirements first."));
            exit();
        }
    } else {
        header("Location: student_history.php?msg=" . urlencode("⚠️ Request already submitted."));
        exit();
    }
}

// === 3. Signatory types map ===
$signatory_types_map = [];
$mapq = $conn->query("SELECT username, signatory_type FROM users WHERE role='signatory'");
if ($mapq) while($m = $mapq->fetch_assoc()) $signatory_types_map[$m['username']] = $m['signatory_type'];

// === 4. Get ALL Assigned Signatories & Track Progress ===
$assigned_signatories_list = [];
$total_required = 0;
$approved_count = 0;

$approved_from_apps = [];
$app_check = $conn->prepare("SELECT signatory FROM applications WHERE username = ? AND status = 'Approved'");
$app_check->bind_param("s", $username);
$app_check->execute();
$ac_res = $app_check->get_result();
while($a = $ac_res->fetch_assoc()){ $approved_from_apps[] = $a['signatory']; }
$app_check->close();

$assigned_q = $conn->prepare("
    SELECT cr.id, u.username, u.signatory_type, cr.document_type_id
    FROM course_requirements cr
    JOIN users u ON cr.signatory_id = u.id
    WHERE cr.course_id = (SELECT id FROM courses WHERE course_name = ? LIMIT 1)
    AND u.status = 'active'
");
$assigned_q->bind_param("s", $user_course);
$assigned_q->execute();
$assigned_res = $assigned_q->get_result();

if ($assigned_res) {
    while ($row = $assigned_res->fetch_assoc()) {
        $total_required++;
        $sig_user = $row['username'];
        $is_no_file = (trim($row['document_type_id']) === 'N/A' || trim($row['document_type_id']) === '');

        if (in_array($sig_user, $approved_from_apps)) {
            $approved_count++;
            $assigned_signatories_list[$sig_user] = [
                'type' => $row['signatory_type'],
                'is_cleared' => true,
                'note' => $is_no_file ? 'Auto-Cleared (No File Required)' : 'Document Approved'
            ];
        } else {
            $assigned_signatories_list[$sig_user] = [
                'type' => $row['signatory_type'],
                'is_cleared' => false,
                'note' => 'Not Yet Complied'
            ];
        }
    }
}
$assigned_q->close();

$can_request_verification = ($approved_count >= $total_required && $total_required > 0);

// === 5. Fetch Full History ===
$applications = [];
$app_res = $conn->prepare("SELECT id, signatory, course, document, status, rejection_reason, submitted_at, reviewed_at FROM applications WHERE username = ? ORDER BY submitted_at DESC");
$app_res->bind_param("s", $username);
$app_res->execute();
$ar = $app_res->get_result();
if ($ar) while($row = $ar->fetch_assoc()) $applications[] = $row;
$app_res->close();

// === 6. DYNAMIC MAPPING LOGIC for Print ===
// Only include signatories actually assigned to this student's course.
// Registrar is excluded here — shown separately at the bottom of the clearance form.

// Get signatory full names
$signatory_names = [];
$name_query = $conn->query("SELECT username, full_name FROM users WHERE role='signatory'");
if ($name_query) {
    while($n = $name_query->fetch_assoc()) {
        $signatory_names[$n['username']] = $n['full_name'];
    }
}

// Build dynamic print signatories from $assigned_signatories_list
$sigs_data = [];
foreach ($assigned_signatories_list as $user => $data) {
    $stype = $data['type'];
    // Skip Registrar — they sign as College Registrar at the bottom
    if (stripos($stype, 'Registrar') !== false) continue;

    $sigs_data[$stype] = [
        'label'    => $stype,
        'approved' => $data['is_cleared'],
        'date'     => $data['is_cleared'] ? date('m/d/Y') : '',
        'name'     => $signatory_names[$user] ?? ''
    ];
}

// Get College Registrar info
$registrar_name = '';
$reg_query = $conn->query("SELECT full_name FROM users WHERE role='signatory' AND signatory_type LIKE '%Registrar%' LIMIT 1");
if ($reg_query && $reg_query->num_rows > 0) {
    $registrar_name = $reg_query->fetch_assoc()['full_name'];
}

$msg = $_GET['msg'] ?? '';
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>History & Verification | Smart Clearance System</title>
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link rel="stylesheet" href="styles.css"> 
<style>
.clearance-container{width:90%;margin:30px auto;background:rgba(255,255,255,0.95);border-radius:10px;padding:20px;text-align:center;box-shadow:0 4px 8px rgba(0,0,0,0.1);}
.clearance-header{display:flex;justify-content:center;align-items:center;background:darkgreen;color:white;border-radius:25px;padding:10px 20px;margin-bottom:30px;}
.clearance-header h2{font-size:20px;font-weight:700;}
table{border-collapse:collapse;width:100%;margin-top:20px;}
table th,table td{padding:10px;border:1px solid #ddd;text-align:center;}
table th{background:darkgreen;color:white;}
.status{padding:5px 10px; border-radius: 5px; font-weight: bold;}
.status.Pending{background:#007bff;color:white;}
.status.Approved{background:#28a745;color:white;}

.verification-card {
    background: linear-gradient(135deg, #155724 0%, #0d3d1a 100%);
    color: white; padding: 25px; border-radius: 15px; margin-bottom: 30px; text-align: left;
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}
.progress-bar { background: rgba(255,255,255,0.2); height: 25px; border-radius: 15px; overflow: hidden; margin: 15px 0; border: 1px solid rgba(255,255,255,0.3); }
.progress-fill { background: #28a745; height: 100%; display: flex; align-items: center; justify-content: center; font-weight: bold; transition: width 0.8s ease; }
.btn-request { background: #ffc107; color: #000; border: none; padding: 12px 25px; font-size: 16px; font-weight: 700; cursor: pointer; border-radius: 8px; transition: 0.3s; }
.btn-request:disabled { background: #6c757d; color: #fff; cursor: not-allowed; opacity: 0.5; }
.btn-request:hover:not(:disabled) { background: #e0a800; transform: translateY(-2px); }
.status-badge { display: inline-block; padding: 10px 20px; border-radius: 30px; font-weight: 700; margin-top: 10px; }
.badge-review { background: #17a2b8; color: white; }
.badge-approved { background: #28a745; color: white; }

.print-btn { background: #0069d9; color: white; border: none; padding: 12px 25px; font-size: 16px; cursor: pointer; border-radius: 8px; float: right; display: flex; align-items: center; gap: 10px; font-weight: bold; }
.print-btn:disabled { background: #6c757d; cursor: not-allowed; }
.print-btn:hover:not(:disabled) { background: #0056b3; transform: translateY(-2px); }

#printableForm { display: none; }
@media print {
    body * { visibility: hidden; }
    #printableForm, #printableForm * { visibility: visible; }
    #printableForm { display: block !important; position: absolute; left: 0; top: 0; width: 100%; }
    .sidebar, .home, .verification-card, .clearance-container { display: none !important; }
}

.alert-message {
    background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; text-align: center;
    animation: slideDown 0.5s ease;
}
.alert-message.error { background: #f8d7da; border-color: #f5c6cb; color: #721c24; }
.alert-message.warning { background: #fff3cd; border-color: #ffeaa7; color: #856404; }
@keyframes slideDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
</style>
</head>
<body>

<?php include 'sidebar_student.php'; ?>

<section class="home">
    <div class="text">
        <div class="clearance-header">
            <h2>APPLICATION HISTORY & STATUS</h2>
        </div>
    </div>

    <div class="clearance-container" style="text-align: left;">
        <?php if (!empty($msg)): 
            $msgClass = 'alert-message';
            if (strpos($msg, '❌') !== false) $msgClass .= ' error';
            elseif (strpos($msg, '⚠️') !== false) $msgClass .= ' warning';
        ?>
        <div class="<?= $msgClass ?>">
            <i class='bx bx-info-circle' style="font-size: 20px; vertical-align: middle;"></i>
            <strong><?= h($msg) ?></strong>
        </div>
        <?php endif; ?>
        
        <div class="verification-card">
            <h3><i class='bx bx-badge-check'></i> Clearance Verification</h3>
            <p>To generate your final clearance, you must be cleared by all assigned signatories.</p>
            
            <div class="progress-bar">
                <?php 
                $progress_percent = ($total_required > 0) ? round(($approved_count / $total_required) * 100) : 0;
                ?>
                <div class="progress-fill" style="width: <?= $progress_percent ?>%;">
                    <?= $progress_percent ?>% Completed (<?= $approved_count ?> / <?= $total_required ?>)
                </div>
            </div>

            <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 20px;">
                <div>
                    <?php if ($admin_approved == 1): ?>
                        <span class="status-badge badge-approved"><i class='bxs-check-circle'></i> FINAL CLEARANCE APPROVED</span>
                    <?php elseif ($final_clearance_status === 'pending'): ?>
                        <span class="status-badge badge-review"><i class='bx bx-sync bx-spin'></i> PENDING ADMIN VERIFICATION</span>
                    <?php else: ?>
                        <form method="POST" onsubmit="return confirm('Submit verification request to admin?');">
                            <button type="submit" name="request_verification" class="btn-request" <?= !$can_request_verification ? 'disabled' : '' ?>>
                                <i class='bx bx-send'></i> REQUEST VERIFICATION TO ADMIN
                            </button>
                        </form>
                    <?php endif; ?>
                </div>

                <?php if ($admin_approved == 1): ?>
                <button onclick="window.print()" class="print-btn">
                    <i class='bx bx-printer'></i> GENERATE CLEARANCE FORM
                </button>
                <?php endif; ?>
            </div>
            
            <?php if (!$can_request_verification && $final_clearance_status === 'not_requested'): ?>
                <p style="color: #ffc107; font-size: 13px; margin-top: 10px;">
                    <i class='bx bx-info-circle'></i> Complete all signatory requirements first.
                </p>
            <?php endif; ?>
        </div>

        <h3 style="color: darkgreen; margin-bottom: 15px;">Signatory Checklist</h3>
        <table>
            <thead>
                <tr>
                    <th>Signatory Type</th>
                    <th>Status</th>
                    <th>Note</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($assigned_signatories_list as $sig_user => $data): ?>
                <tr>
                    <td><?= h($data['type']) ?></td>
                    <td>
                        <span class="status <?= $data['is_cleared'] ? 'Approved' : 'Pending' ?>">
                            <?= $data['is_cleared'] ? '✅ CLEARED' : '⏳ PENDING' ?>
                        </span>
                    </td>
                    <td><small><?= h($data['note']) ?></small></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h3 style="color: darkgreen; margin-top: 40px; margin-bottom: 15px;">Submission History</h3>
        <table>
            <thead>
                <tr>
                    <th>Date Submitted</th>
                    <th>Signatory</th>
                    <th>Document</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($applications)): ?>
                    <tr><td colspan="4">No documents submitted yet.</td></tr>
                <?php else: foreach($applications as $app): 
                    $row_class = str_replace(' ', '', $app['status']);
                ?>
                    <tr>
                        <td><?= h(date('M d, Y h:i A', strtotime($app['submitted_at']))) ?></td>
                        <td><?= h($signatory_types_map[$app['signatory']] ?? $app['signatory']) ?></td>
                        <td>
                            <?php if($app['document'] === 'N/A'): ?>
                                <span style="color:#888; font-style: italic;">No file required</span>
                            <?php else: ?>
                                <a href="uploads/<?= h($app['document']) ?>" target="_blank" style="color: blue; text-decoration: underline;">View File</a>
                            <?php endif; ?>
                        </td>
                        <td><span class="status <?= h($row_class) ?>"><?= h($app['status']) ?></span></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</section>

<!-- PRINTABLE CLEARANCE FORM -->
<div id="printableForm">
    <div style="position: relative; text-align: center; font-family: Arial, sans-serif; padding: 30px 40px; max-width: 800px; margin: 0 auto; min-height: 100vh;">
        
        <!-- BACKGROUND LOGO -->
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); opacity: 0.08; z-index: 0; width: 400px; height: 400px;">
            <img src="uploads/bpc-logo_1763531883.png" style="width: 100%; height: 100%; object-fit: contain;" alt="BPC Logo">
        </div>

        <!-- CONTENT (above background) -->
        <div style="position: relative; z-index: 1;">
            
            <!-- HEADER -->
            <div style="margin-bottom: 25px;">
                <h2 style="margin: 0; color: #006400; font-size: 20px; font-weight: bold;">BULACAN POLYTECHNIC COLLEGE</h2>
                <p style="margin: 3px 0; font-size: 12px;">Bulihan, City of Malolos, Bulacan, Philippines</p>
                <p style="margin: 3px 0; font-size: 11px;">(044) 802 6716 / (044) 796 2306</p>
                <h3 style="margin: 20px 0 25px 0; font-size: 16px; font-weight: bold;">STUDENT CLEARANCE FORM</h3>
            </div>
            
            <!-- STUDENT INFORMATION (Two Column Layout) -->
            <div style="text-align: left; margin-bottom: 30px; font-size: 13px;">
                <table style="width: 100%; border-collapse: collapse; border: none;">
                    <tr>
                        <td style="border: none; padding: 6px 5px; width: 15%;"><strong>Name:</strong></td>
                        <td style="border: none; border-bottom: 1px solid #000; padding: 6px 5px; width: 35%;"><?= h($full_name) ?></td>
                        <td style="border: none; padding: 6px 5px; width: 15%;"><strong>Section:</strong></td>
                        <td style="border: none; border-bottom: 1px solid #000; padding: 6px 5px; width: 35%;"><?= h($user_section) ?></td>
                    </tr>
                    <tr>
                        <td style="border: none; padding: 6px 5px;"><strong>Course & Year:</strong></td>
                        <td style="border: none; border-bottom: 1px solid #000; padding: 6px 5px;"><?= h($user_course) ?> - <?= h($user_year) ?></td>
                        <td style="border: none; padding: 6px 5px;"><strong>Academic Year:</strong></td>
                        <td style="border: none; border-bottom: 1px solid #000; padding: 6px 5px;"><?= h($academic_year) ?></td>
                    </tr>
                    <tr>
                        <td style="border: none; padding: 6px 5px;"><strong>Email:</strong></td>
                        <td style="border: none; border-bottom: 1px solid #000; padding: 6px 5px;"><?= h($user_email) ?></td>
                        <td style="border: none; padding: 6px 5px;"><strong>Semester:</strong></td>
                        <td style="border: none; border-bottom: 1px solid #000; padding: 6px 5px;"><?= h($semester) ?></td>
                    </tr>
                </table>
            </div>

            <!-- SIGNATORIES SECTION — Dynamic: only assigned signatories appear -->
            <div style="margin-top: 35px;">
                <h4 style="text-align: center; font-size: 14px; margin-bottom: 15px; font-weight: bold;">Signatories</h4>
                
                <table style="width: 100%; border: 1px solid #000; border-collapse: collapse; font-size: 12px;">
                    <?php if (empty($sigs_data)): ?>
                    <tr>
                        <td colspan="2" style="border: 1px solid #000; padding: 10px; text-align: center; color: #888;">
                            No signatories assigned.
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach($sigs_data as $key => $data): ?>
                    <tr>
                        <td style="border: 1px solid #000; padding: 10px; width: 35%; text-align: left; vertical-align: middle;">
                            <?= h($data['label']) ?>:
                        </td>
                        <td style="border: 1px solid #000; padding: 10px; width: 65%; vertical-align: middle;">
                            <?php if($data['approved']): ?>
                                <span style="color: green; font-size: 11px;">✓ SIGNED - <?= h($data['date']) ?></span>
                                <?php if(!empty($data['name'])): ?>
                                    <span style="margin-left: 10px; font-size: 11px; color: #333;">(<?= h($data['name']) ?>)</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span style="color: #aaa; font-size: 11px; font-style: italic;">Not yet signed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </table>
            </div>

            <!-- CERTIFICATION & COLLEGE REGISTRAR -->
            <div style="margin-top: 40px; padding-top: 20px;">
                <h4 style="text-align: center; font-size: 14px; margin-bottom: 20px; font-weight: bold;">CERTIFICATION</h4>
                <p style="font-size: 12px; margin-bottom: 40px; text-align: center;">
                    I hereby certify that the above named student has no pending accountable requirements as required by<br>
                    Bulacan Polytechnic College.
                </p>
                
                <div style="text-align: center;">
                    <?php if ($admin_approved == 1): ?>
                        <div style="margin-bottom: 10px;">
                            <span style="color: green; font-weight: bold; font-size: 14px;">✓ SIGNED - <?= date('m/d/Y') ?></span>
                        </div>
                        <div style="border-bottom: 2px solid #000; width: 300px; margin: 0 auto 5px;"></div>
                        <?php if(!empty($registrar_name)): ?>
                            <div style="font-size: 13px; margin-bottom: 3px;"><?= h($registrar_name) ?></div>
                        <?php endif; ?>
                        <strong style="font-size: 13px;">College Registrar</strong>
                    <?php else: ?>
                        <div style="height: 60px;"></div>
                        <div style="border-bottom: 2px solid #000; width: 300px; margin: 0 auto 5px;"></div>
                        <strong style="font-size: 13px;">College Registrar</strong>
                        <div style="margin-top: 3px; font-size: 11px;">Date: __________</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const body = document.querySelector("body"),
          sidebar = body.querySelector(".sidebar"),
          toggle = body.querySelector(".toggle");

    toggle.addEventListener("click", () => {
        sidebar.classList.toggle("close");
    });
</script>
</body>
</html>