<style>
    :root {
        --sidebar-width: 320px; 
        --sidebar-close-width: 88px;
        --sidebar-color: #006400 !important; /* Siguradong Green */
        --text-color: #ffffff;
        --tran-05: all 0.5s ease;
    }

    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        height: 100%;
        width: var(--sidebar-width);
        padding: 10px 14px;
        background: var(--sidebar-color);
        transition: var(--tran-05);
        z-index: 9999 !important; /* Pinaka-ibabaw sa lahat */
        box-shadow: 4px 0 10px rgba(0,0,0,0.3);
    }

    .sidebar.close {
        width: var(--sidebar-close-width);
    }

    /* Header Section */
    .sidebar .image-text {
        display: flex;
        align-items: center;
        gap: 12px;
        width: 100%;
    }

    .sidebar .image img {
        width: 45px;
        border-radius: 6px;
    }

    .sidebar .header-text {
        display: flex;
        flex-direction: column;
        white-space: nowrap;
        overflow: hidden;
        opacity: 1;
        transition: var(--tran-05);
    }

    .sidebar.close .header-text {
        opacity: 0;
        pointer-events: none;
    }

    .header-text .name {
        font-size: 18px; 
        font-weight: 600;
        color: var(--text-color);
        text-overflow: ellipsis;
        overflow: hidden;
    }

    .header-text .role {
        font-size: 13px;
        color: rgba(255,255,255,0.7);
        display: block;
    }

    /* Toggle Button - CRITICAL FIX */
    .sidebar .toggle {
        position: absolute;
        top: 30px; /* Nilipat sa taas para hindi matakpan ng dashboard cards */
        right: -15px;
        height: 30px;
        width: 30px;
        background-color: #f39c12 !important; /* Orange para kitang-kita */
        color: #fff !important;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        cursor: pointer !important;
        z-index: 10000 !important; /* Higit pa sa sidebar */
        transition: var(--tran-05);
    }

    .sidebar.close .toggle {
        transform: rotate(0deg);
    }

    .sidebar:not(.close) .toggle {
        transform: rotate(180deg);
    }

    /* Menu Links */
    .sidebar .menu-bar {
        height: calc(100% - 70px);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        margin-top: 20px;
    }

    .sidebar li {
        height: 50px;
        list-style: none;
        display: flex;
        align-items: center;
        margin-top: 10px;
    }

    .sidebar li .icon, .sidebar li .text {
        color: var(--text-color);
    }

    .sidebar li a {
        display: flex;
        align-items: center;
        height: 100%;
        width: 100%;
        border-radius: 6px;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .sidebar li a:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }

    .sidebar li .icon {
        min-width: 60px;
        font-size: 20px;
        display: flex;
        justify-content: center;
    }

    .sidebar .text {
        font-size: 16px;
        font-weight: 500;
        transition: var(--tran-05);
    }

    .sidebar.close .text {
        opacity: 0;
    }
</style>

<nav class="sidebar close" id="mainSidebar">
    <header style="position: relative;">
        <div class="image-text">
            <span class="image"><img src="bpc-logo.png" alt="Logo"></span>
            <div class="text header-text">
                <span class="name"><?php echo htmlspecialchars($signatoryFullName ?? 'Admin'); ?></span>
                <span class="role"><?php echo htmlspecialchars($userRole ?? 'Administrator'); ?></span>
            </div>
        </div>
        <i class='bx bx-chevron-right toggle' id="sidebarToggle"></i>
    </header>

    <div class="menu-bar">
        <div class="menu">
            <ul class="menu-links" style="padding: 0;">
                <li class="nav-link">
                    <a href="admin_dashboard.php">
                        <i class='bx bx-home-alt icon'></i>
                        <span class="text nav-text">Dashboard</span>
                    </a>
                </li>
                <li class="nav-link">
                    <a href="manage_students.php">
                        <i class='bx bx-list-check icon'></i>
                        <span class="text nav-text">Manage Students</span>
                    </a>
                </li>
                <li class="nav-link">
                    <a href="manage_signatories.php">
                        <i class='bx bx-user-check icon'></i>
                        <span class="text nav-text">Manage Signatories</span>
                    </a>
                </li>
                <li class="nav-link">
                    <a href="manage_applications.php">
                        <i class='bx bx-file icon'></i>
                        <span class="text nav-text">Applications</span>
                    </a>
                </li>
                <li class="nav-link">
                    <a href="admin_users.php">
                        <i class='bx bx-group icon'></i>
                        <span class="text nav-text">Users</span>
                    </a>
                </li>
                <li class="nav-link">
        <a href="power_admin.php">
            <i class='bx bx-cog icon'></i>
            <span class="text nav-text">System Settings</span>
        </a>
    </li>
            </ul>
        </div>
        <div class="bottom-content" style="padding: 0;">
            <li>
                <a href="#" onclick="confirmLogout()">
                    <i class='bx bx-log-out icon'></i>
                    <span class="text nav-text">Logout</span>
                </a>
            </li>
        </div>
    </div>
</nav>

<script>
// Gagamit tayo ng direktang ID access para walang kawala
(function() {
    const sidebar = document.getElementById('mainSidebar');
    const toggle = document.getElementById('sidebarToggle');

    if (toggle && sidebar) {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation(); // Iwasan ang pag-trigger ng ibang scripts
            sidebar.classList.toggle('close');
        });
    }
})();

function confirmLogout() {
    if (confirm("Are you sure you want to logout?")) {
        window.location.href = "logout.php";
    }
}
</script>