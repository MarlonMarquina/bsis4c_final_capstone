<?php
// FILE: generate_report_pdf.php
include 'conn.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    die("Access Denied.");
}

// 1. Kunin ang mga filters mula sa URL (GET)
$sem    = $_GET['rep_sem'] ?? 'all';
$sy     = $_GET['rep_sy']  ?? '';
$course = $_GET['rep_course'] ?? 'all';
$year   = $_GET['rep_year']   ?? 'all';
$status = $_GET['rep_status'] ?? 'all';

// 2. Buuin ang SQL Query
// Sinisigurado natin na tama ang column names dito
$query = "SELECT u.* FROM users u WHERE u.role = 'student'";

if ($sem    != 'all') $query .= " AND u.semester = '" . $conn->real_escape_string($sem) . "'";
if (!empty($sy))      $query .= " AND u.school_year = '" . $conn->real_escape_string($sy) . "'";
if ($course != 'all') $query .= " AND u.course = '" . $conn->real_escape_string($course) . "'";
if ($year   != 'all') $query .= " AND u.year = '" . $conn->real_escape_string($year) . "'";

// Status Logic: 'cleared' means 0 pending signatures
if ($status == 'cleared') {
    $query .= " AND NOT EXISTS (SELECT 1 FROM student_requirements sr WHERE sr.student_id = u.id AND sr.status = 'pending')";
} elseif ($status == 'pending') {
    $query .= " AND EXISTS (SELECT 1 FROM student_requirements sr WHERE sr.student_id = u.id AND sr.status = 'pending')";
}

$query .= " ORDER BY u.course ASC, u.full_name ASC";
$result = $conn->query($query);

// I-check kung may error sa query para hindi mag-Fatal Error
if (!$result) {
    die("SQL Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Clearance Summary Report</title>
    <style>
        body { font-family: 'Arial', sans-serif; padding: 40px; color: #333; background: #f0f0f0; }
        .report-page { background: white; padding: 40px; width: 210mm; min-height: 297mm; margin: 0 auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .header { text-align: center; border-bottom: 2px solid #006400; padding-bottom: 10px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; font-size: 12px; }
        th { background: #006400; color: white; }
        .no-print { position: fixed; top: 20px; right: 20px; }
        .btn { padding: 10px 20px; background: #006400; color: white; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; }
        @media print { .no-print { display: none; } body { background: white; padding: 0; } .report-page { box-shadow: none; margin: 0; width: 100%; } }
    </style>
</head>
<body>

<div class="no-print">
    <button class="btn" onclick="window.print()">Print to PDF</button>
    <button class="btn" style="background: #666;" onclick="window.close()">Close</button>
</div>

<div class="report-page">
    <div class="header">
        <h1 style="color: #006400; margin: 0;">Smart Clearance System</h1>
        <h2 style="margin: 5px 0;">Student Clearance Summary</h2>
        <p>Semester: <?= htmlspecialchars($sem) ?> | School Year: <?= htmlspecialchars($sy) ?></p>
        <p><small>Filters: Course: <?= $course ?> | Year: <?= $year ?> | Status: <?= $status ?></small></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Full Name</th>
                <th>Course</th>
                <th>Year & Section</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['full_name']) ?></td>
                        <td><?= htmlspecialchars($row['course']) ?></td>
                        <td><?= htmlspecialchars($row['year']) ?> - <?= htmlspecialchars($row['section']) ?></td>
                        <td>
                            <?php
                            $sid = $row['id'];
                            $check = $conn->query("SELECT COUNT(*) as p FROM student_requirements WHERE student_id = $sid AND status = 'pending'");
                            $pcount = $check->fetch_assoc()['p'];
                            echo ($pcount == 0) ? "<b style='color:green;'>CLEARED</b>" : "<span style='color:red;'>$pcount Pending</span>";
                            ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" style="text-align:center;">No students found for this filter.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>