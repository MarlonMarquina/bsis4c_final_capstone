<?php
// signatory_action.php - CLEAN REWRITE
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != "signatory") {
    header("Location: login.php");
    exit();
}

include 'conn.php';

$signatory_name = $_SESSION['username'];
$reviewed_at    = date('Y-m-d H:i:s');

// ── HELPER: Send notification ──────────────────────────────────────────────
function sendNotification($conn, $username, $message, $type) {
    global $reviewed_at;
    $stmt = $conn->prepare(
        "INSERT INTO notifications (username, message, type, created_at) VALUES (?, ?, ?, ?)"
    );
    $stmt->bind_param("ssss", $username, $message, $type, $reviewed_at);
    $stmt->execute();
    $stmt->close();
}

function logSignatoryHistory($conn, $app_id, $student, $signatory, $action, $reason, $document) {
    // Siguraduhin na ang column names sa loob ng () ay tugma sa phpMyAdmin mo
    // Halimbawa, kung sa DB mo ay 'status' ang tawag sa action, palitan ang `action` sa `status`
    $stmt = $conn->prepare("INSERT INTO `signatory_history` (`signatory_username`, `student_user`, `action`, `reason`, `remarks`) VALUES (?, ?, ?, ?, ?)");
    
    // Dapat 5 din ang "s" dahil 5 ang columns natin
    $stmt->bind_param("sssss", $signatory, $student, $action, $reason, $document);
    
    $stmt->execute();
    $stmt->close();
}
// ── 1. SINGLE APPROVE ─────────────────────────────────────────────────────
if (isset($_POST['approve'], $_POST['id'])) {
    $app_id = (int)$_POST['id'];

    // Fetch student username + document
    $fetch = $conn->prepare("SELECT username, document FROM applications WHERE id = ?");
    $fetch->bind_param("i", $app_id);
    $fetch->execute();
    $app   = $fetch->get_result()->fetch_assoc();
    $fetch->close();

    $student_username = $app['username']  ?? null;
    $document         = $app['document']  ?? 'no_file';

    $stmt = $conn->prepare(
        "UPDATE applications
         SET status = 'Approved', reviewed_at = ?, rejection_reason = NULL, rejection_count = 0
         WHERE id = ? AND signatory = ? AND status IN ('Pending', 'Requires Action')"
    );
    $stmt->bind_param("sis", $reviewed_at, $app_id, $signatory_name);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected > 0) {
        logSignatoryHistory($conn, $app_id, $student_username, $signatory_name, 'Approved', 'Requirement met and validated', $document);
        if ($student_username) {
            sendNotification($conn, $student_username, "Your application (ID: {$app_id}) has been Approved.", "success");
        }
        header("Location: signatory_dashboard.php?success=approved");
    } else {
        header("Location: signatory_dashboard.php?error=process_error");
    }
    exit();
}

// ── 2. REJECT (Rule of 3) ─────────────────────────────────────────────────
if (isset($_POST['reject'], $_POST['id'], $_POST['reason'])) {
    $app_id           = (int)$_POST['id'];
    $rejection_reason = trim($_POST['reason']);
    $additional_notes = trim($_POST['additional_notes'] ?? '');

    if ($additional_notes !== '') {
        $rejection_reason .= " | Notes: " . $additional_notes;
    }

    // Fetch current rejection count, student, document
    $fetch = $conn->prepare(
        "SELECT username, rejection_count, document FROM applications WHERE id = ? AND signatory = ?"
    );
    $fetch->bind_param("is", $app_id, $signatory_name);
    $fetch->execute();
    $result = $fetch->get_result();

    if ($result->num_rows === 0) {
        $fetch->close();
        header("Location: signatory_dashboard.php?error=not_found");
        exit();
    }

    $app              = $result->fetch_assoc();
    $student_username = $app['username'];
    $current_count    = (int)$app['rejection_count'];
    $document         = $app['document'];
    $fetch->close();

    $new_count = $current_count + 1;

    // Rule of 3: on the 4th rejection, totally reject
    if ($new_count >= 4) {
        $final_status = 'Totally Rejected';
        $redirect     = 'totally_rejected&count=' . $new_count;
    } else {
        $final_status = 'Requires Action';
        $redirect     = 'rejected';
    }

    $stmt = $conn->prepare(
        "UPDATE applications
         SET status = ?, reviewed_at = ?, rejection_reason = ?, rejection_count = ?
         WHERE id = ? AND signatory = ?"
    );
    // s=status, s=reviewed_at, s=reason, i=count, i=id, s=signatory
    $stmt->bind_param("sssiis", $final_status, $reviewed_at, $rejection_reason, $new_count, $app_id, $signatory_name);
    $stmt->execute();
    $stmt->close();

    logSignatoryHistory($conn, $app_id, $student_username, $signatory_name, $final_status, $rejection_reason, $document);

    if ($student_username) {
        if ($final_status === 'Requires Action') {
            $msg  = "Application (ID: {$app_id}) returned for revision (Attempt {$new_count}/3). Reason: {$rejection_reason}";
            $type = "warning";
        } else {
            $msg  = "Application (ID: {$app_id}) has been TOTALLY REJECTED after {$new_count} attempts.";
            $type = "danger";
        }
        sendNotification($conn, $student_username, $msg, $type);
    }

    header("Location: signatory_dashboard.php?success=" . $redirect);
    exit();
}

// ── 3. BULK APPROVE ───────────────────────────────────────────────────────
if (isset($_POST['accept_all'])) {
    $fetch = $conn->prepare(
        "SELECT id, username, document FROM applications WHERE signatory = ? AND status = 'Pending'"
    );
    $fetch->bind_param("s", $signatory_name);
    $fetch->execute();
    $pending_apps = $fetch->get_result()->fetch_all(MYSQLI_ASSOC);
    $fetch->close();

    $count_approved = 0;

    foreach ($pending_apps as $app) {
        $up = $conn->prepare(
            "UPDATE applications SET status = 'Approved', reviewed_at = ?, rejection_count = 0 WHERE id = ?"
        );
        $up->bind_param("si", $reviewed_at, $app['id']);
        if ($up->execute()) {
            $count_approved++;
            logSignatoryHistory($conn, $app['id'], $app['username'], $signatory_name, 'Approved (Bulk)', 'Requirement met', $app['document']);
            sendNotification($conn, $app['username'], "Your application (ID: {$app['id']}) was approved via Bulk Action.", "success");
        }
        $up->close();
    }

    header("Location: signatory_dashboard.php?success=bulk_approved&count={$count_approved}");
    exit();
}

// Fallback
header("Location: signatory_dashboard.php");
exit();