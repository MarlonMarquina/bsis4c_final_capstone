<?php
// handle_otp.php (LIVE EMAIL OTP ONLY)

// --- DEBUGGING & CONFIGURATION ---
// I-log ang lahat ng errors, pero huwag i-display sa screen para hindi masira ang JSON
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Tiyakin na TAMA ang path ng vendor/autoload.php
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

session_start();
// I-include ang iyong database connection
// Kung hindi ginagamit sa file na ito, optional ang conn.php, pero panatilihin natin kung may plano
// include 'conn.php'; 

header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);

$action = $input['action'] ?? '';
$type = $input['type'] ?? ''; 
$destination = $input['destination'] ?? ''; 

$username = $_SESSION['username'] ?? '';
if (!$username || $_SESSION['role'] !== 'student') {
    http_response_code(403); 
    echo json_encode(['success' => false, 'message' => 'Unauthorized access or session expired.']);
    exit;
}

// --- CRITICAL CONFIGURATION: Email Settings ---
$smtpHost = 'smtp.gmail.com'; 
$smtpUsername = 'clearancebpc@gmail.com'; // IYONG GMAIL EMAIL ADDRESS
$smtpPassword = 'powe wgem hlsv ybyq'; // IYONG APP PASSWORD (Siguraduhing walang space)
$smtpPort = 587; 
// ----------------------------------------------


if ($action === 'send') {
    $destination = trim($destination);
    
    if ($type !== 'email' || !filter_var($destination, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid request type or email format.']);
        exit;
    }
    
    // 1. Generate OTP
    $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    $expiry = time() + 300; // 5 minutes expiry

    // 2. Store OTP in session
    $_SESSION['temp_otp_' . $type] = [
        'code' => $otp, 
        'destination' => $destination, 
        'expiry' => $expiry
    ]; 
    // I-clear ang validation flag bago magpadala ulit
    unset($_SESSION['email_otp_validated']); 

    // 3. SENDING LOGIC (EMAIL ONLY)
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = $smtpHost;
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtpUsername;
        $mail->Password   = $smtpPassword; // App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; 
        $mail->Port       = $smtpPort;
        // $mail->SMTPDebug  = SMTP::DEBUG_SERVER; // I-uncomment para sa detalye ng koneksyon

        // Recipients
        $mail->setFrom($smtpUsername, 'Smart Clearance System');
        $mail->addAddress($destination);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Smart Clearance OTP Verification';
        $mail->Body    = "Your one-time password (OTP) is: <b>$otp</b>. This code expires in 5 minutes.";
        $mail->AltBody = "Your one-time password (OTP) is: $otp. This code expires in 5 minutes.";

        $mail->send();
        
        echo json_encode(['success' => true, 'message' => 'OTP sent successfully to ' . $destination . '.']);

    } catch (Exception $e) {
        // Log ang error para ma-check sa server logs
        error_log('PHPMailer Error in handle_otp.php: ' . $mail->ErrorInfo . ' | Destination: ' . $destination);
        // I-clear ang session
        unset($_SESSION['temp_otp_' . $type]);

        // Ibigay ang PHPMailer error sa AJAX response
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => "Email sending failed. Error: " . $mail->ErrorInfo]);
    }
} 
elseif ($action === 'verify') {
    $submitted_otp = $input['otp'] ?? '';
    $type = $input['type'] ?? ''; 
    $destination = $input['destination'] ?? ''; 
    
    $stored_otp_data = $_SESSION['temp_otp_' . $type] ?? null;
    $is_valid = false;

    if ($stored_otp_data) {
        // Check destination, code, and expiry
        if ($stored_otp_data['destination'] === $destination) {
            if ($stored_otp_data['code'] === $submitted_otp) {
                if ($stored_otp_data['expiry'] > time()) {
                    $is_valid = true;
                    $_SESSION['email_otp_validated'] = true; 
                    unset($_SESSION['temp_otp_' . $type]); // Clear stored OTP
                } else {
                    unset($_SESSION['temp_otp_' . $type]); // Clear expired OTP
                    echo json_encode(['success' => false, 'message' => 'OTP expired. Please request a new one.']);
                    exit;
                }
            }
        }
    }

    if ($is_valid) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid OTP. Please try again.']);
    }
} else {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid action.']);
}
?>