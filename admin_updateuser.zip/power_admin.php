<?php
// FILE: power_admin.php
include 'conn.php';
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: login.php"); exit();
}

$msg = '';

// --- 1. HANDLE SETTINGS UPDATE ---
if (isset($_POST['update_settings'])) {
    $sem = $_POST['semester'];
    $sy = $_POST['school_year'];
    $stmt = $conn->prepare("UPDATE system_settings SET current_semester=?, current_school_year=? WHERE id=1");
    $stmt->bind_param("ss", $sem, $sy);
    if ($stmt->execute()) {
        $msg = "✅ System settings updated successfully!";
    }
}

// --- 2. HANDLE GLOBAL TERM SYNC ---
if (isset($_POST['sync_students'])) {
    $active_settings = $conn->query("SELECT * FROM system_settings WHERE id=1")->fetch_assoc();
    $sem = $active_settings['current_semester'];
    $sy = $active_settings['current_school_year'];

    $stmt = $conn->prepare("UPDATE users SET semester=?, school_year=? WHERE role='student'");
    $stmt->bind_param("ss", $sem, $sy);
    if ($stmt->execute()) {
        $msg = "✅ All student accounts synced to $sem | $sy!";
    }
}

$settings = $conn->query("SELECT * FROM system_settings WHERE id=1")->fetch_assoc();
if (!$settings) {
    $settings = ['current_semester' => '1st Semester', 'current_school_year' => '2025-2026'];
}

$courses = $conn->query("SELECT DISTINCT course_name FROM courses ORDER BY course_name ASC");

// Set Sidebar Variables
$admin_user = $_SESSION['username'];
$admin_stmt = $conn->prepare("SELECT full_name FROM users WHERE username = ? AND role = 'admin'");
$admin_stmt->bind_param("s", $admin_user);
$admin_stmt->execute();
$admin_data = $admin_stmt->get_result()->fetch_assoc();
$signatoryFullName = !empty($admin_data['full_name']) ? $admin_data['full_name'] : $admin_user;
$userRole = "Administrator"; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>System Settings | Power Admin</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body { font-family: 'Poppins', sans-serif; background:#f4f7f6; margin: 0; padding: 0; }
        
        .home { 
            position: relative; 
            margin-left: 88px; 
            width: calc(100% - 88px); 
            transition: 0.5s; 
            padding: 20px;
            box-sizing: border-box;
        }

        .dashboard-header { 
            background: linear-gradient(135deg, #2d5016 0%, #1a3409 100%);
            color: white; 
            padding: 20px; 
            border-radius: 12px; 
            text-align: center; 
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .dashboard-header h2 { margin: 0; font-size: 24px; letter-spacing: 1px; }

        .card { 
            background: #fff; 
            padding: 30px; 
            border-radius: 15px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.05); 
            margin-bottom: 25px; 
            border: 1px solid #eef0f2;
        }

        .section-title { 
            color: #2d5016; 
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 20px; 
            display: flex; 
            align-items: center; 
            gap: 10px;
            border-bottom: 2px solid #f0f2f5;
            padding-bottom: 10px;
        }

        .grid-settings { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        
        label { font-weight: 600; display: block; margin-bottom: 8px; color: #333; font-size: 13px; text-transform: uppercase; }
        
        select, input { 
            width: 100%; 
            padding: 12px; 
            border-radius: 8px; 
            border: 2px solid #e0e0e0; 
            background: #fff; 
            outline: none; 
            transition: 0.3s;
        }

        select:focus, input:focus { border-color: #2d5016; }
        
        .button-row { display: flex; gap: 15px; margin-top: 20px; }

        .btn {
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.3s;
            border: none;
            font-size: 14px;
        }

        .btn-save { background: #2d5016; color: white; }
        .btn-save:hover { background: #1a3409; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(45,80,22,0.3); }
        
        .btn-sync { background: #3498db; color: white; }
        .btn-sync:hover { background: #2980b9; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(52,152,219,0.3); }

        .btn-report { 
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%); 
            color: white; 
            width: 100%; 
            justify-content: center;
            margin-top: 25px;
            padding: 15px;
            font-size: 16px;
        }
        .btn-report:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(230,126,34,0.4); }
        
        .report-filter { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .info-txt { font-size: 13px; color: #7f8c8d; margin-bottom: 15px; display: block; line-height: 1.5; }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
            border: 1px solid transparent;
        }
        .alert-success { background: #d4edda; color: #155724; border-color: #c3e6cb; }
    </style>
</head>
<body>

<?php include 'sidebar_admin.php'; ?>

<section class="home">
    <div style="max-width: 1000px; margin: 0 auto;">
        
        <div class="dashboard-header">
            <h2><i class='bx bx-shield-quarter'></i> SYSTEM CONTROL PANEL</h2>
        </div>

        <?php if($msg): ?>
            <div class="alert alert-success">
                <i class='bx bx-check-circle'></i> <?= $msg ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="section-title"><i class='bx bx-cog'></i> Global System Settings</div>
            <span class="info-txt">Update the active academic term. Use the "Sync" button to force update all existing student profiles to this term.</span>
            
            <form method="POST">
                <div class="grid-settings">
                    <div>
                        <label>Active Semester</label>
                        <select name="semester">
                            <option value="1st Semester" <?= ($settings['current_semester'] == '1st Semester') ? 'selected' : '' ?>>1st Semester</option>
                            <option value="2nd Semester" <?= ($settings['current_semester'] == '2nd Semester') ? 'selected' : '' ?>>2nd Semester</option>
                            <option value="Summer" <?= ($settings['current_semester'] == 'Summer') ? 'selected' : '' ?>>Summer</option>
                        </select>
                    </div>
                    <div>
                        <label>Active School Year</label>
                        <input type="text" name="school_year" value="<?= htmlspecialchars($settings['current_school_year']) ?>" placeholder="e.g. 2025-2026">
                    </div>
                </div>
                
                <div class="button-row">
                    <button type="submit" name="update_settings" class="btn btn-save">
                        <i class='bx bx-save'></i> Update Active Term
                    </button>
                    
                    <button type="submit" name="sync_students" class="btn btn-sync" onclick="return confirm('Update ALL existing students to this term?')">
                        <i class='bx bx-refresh'></i> Sync Student Term
                    </button>
                </div>
            </form>
        </div>

        <div class="card">
            <div class="section-title"><i class='bx bx-printer'></i> Clearance Summary Report</div>
            <span class="info-txt">Generate a professional PDF summary. You can filter by status, course, or year level.</span>
            
            <form action="generate_report_pdf.php" method="GET" target="_blank">
                <div class="report-filter">
                    <div>
                        <label>Semester</label>
                        <select name="rep_sem">
                            <option value="all">All Semesters</option>
                            <option value="1st Semester">1st Semester</option>
                            <option value="2nd Semester">2nd Semester</option>
                            <option value="Summer">Summer</option>
                        </select>
                    </div>
                    <div>
                        <label>School Year</label>
                        <input type="text" name="rep_sy" value="<?= htmlspecialchars($settings['current_school_year']) ?>">
                    </div>
                    <div>
                        <label>Department / Course</label>
                        <select name="rep_course">
                            <option value="all">All Courses</option>
                            <?php 
                            $courses->data_seek(0);
                            while($c = $courses->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($c['course_name']) ?>"><?= htmlspecialchars($c['course_name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div>
                        <label>Year Level</label>
                        <select name="rep_year">
                            <option value="all">All Years</option>
                            <option value="1st Year">1st Year</option>
                            <option value="2nd Year">2nd Year</option>
                            <option value="3rd Year">3rd Year</option>
                            <option value="4th Year">4th Year</option>
                        </select>
                    </div>
                    <div style="grid-column: span 1;">
                        <label>Clearance Status</label>
                        <select name="rep_status">
                            <option value="all">All Students</option>
                            <option value="cleared">Fully Cleared</option>
                            <option value="pending">Pending/Uncleared</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn btn-report">
                    <i class='bx bxs-file-pdf'></i> GENERATE SUMMARY PDF
                </button>
            </form>
        </div>
    </div>
</section>

</body>
</html>