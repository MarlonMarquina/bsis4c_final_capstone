<?php
// Database Configuration
$host = "localhost";    // Keep as 'localhost' for XAMPP
$user = "root";         // Default XAMPP username
$pass = "";             // Default XAMPP password is empty
$dbname = "school_db";  // Your database name

/* If you move this to your online server (IONOS), use these instead:
   $host = "db5019018582.hosting-data.io";
   $user = "dbu3860300";
   $pass = "YOUR_PASSWORD_HERE";
*/

// Set error reporting to throw exceptions for easier debugging
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // Establishing the connection
    $conn = mysqli_connect($host, $user, $pass, $dbname);

    // Set character set to ensure special characters display correctly
    mysqli_set_charset($conn, "utf8mb4");

} catch (mysqli_sql_exception $e) {
    // If connection fails, show a clean error message
    die("Database Connection Failed: " . $e->getMessage());
}
?>