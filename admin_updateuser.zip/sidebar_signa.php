<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="styles.css">
    <nav class="sidebar close">
    <header>
        <div class="image-text">
            <span class="image"><img src="bpc-logo.png" alt="Logo"></span>
            <div class="text header-text">
                <span class="name"><?php echo htmlspecialchars($signatoryFullName); ?></span>
                <span class="role">Signatory</span>
            </div>
        </div>
        <i class='bx bx-chevron-right toggle'></i>
    </header>

    <div class="menu-bar">
        <div class="menu">
            <ul class="menu-links">
                <li class="nav-link">
                    <a href="signatory_dashboard.php">
                        <i class='bx bx-home-alt icon'></i>
                        <span class="text nav-text">Dashboard</span>
                    </a>
                </li>
                <li class="nav-link">
                    <a href="requirementssigna.php">
                        <i class='bx bx-list-check icon'></i>
                        <span class="text nav-text">Requirements</span>
                    </a>
                </li>
                <li class="nav-link">
                    <a href="signatory_history.php">
                        <i class='bx bx-history icon'></i>
                        <span class="text nav-text">History</span>
                    </a>
                </li>
                <li class="nav-link">
                    <a href="announcement.php">
                        <i class='bx bx-message icon'></i>
                        <span class="text nav-text">Announcements</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="bottom-content">
            <li class="">
                <a href="#" onclick="confirmLogout()">
                    <i class='bx bx-log-out icon'></i>
                    <span class="text nav-text">Logout</span>
                </a>
            </li>
        </div>
    </div>
</nav>
<script>
// Gagamit tayo ng direktang ID access para walang kawala
(function() {
    const sidebar = document.getElementById('mainSidebar');
    const toggle = document.getElementById('sidebarToggle');

    if (toggle && sidebar) {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation(); // Iwasan ang pag-trigger ng ibang scripts
            sidebar.classList.toggle('close');
        });
    }
})();

function confirmLogout() {
    if (confirm("Are you sure you want to logout?")) {
        window.location.href = "logout.php";
    }
}
</script>