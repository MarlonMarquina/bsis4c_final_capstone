<?php
// FILE: requirementssigna.php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != "signatory") {
    header("Location: login.php");
    exit();
}

include 'conn.php';
$signatory = $_SESSION['username'];

// 1. FETCH SIGNATORY INFO
$sigInfoStmt = $conn->prepare("SELECT id, full_name, signatory_type, department FROM users WHERE username = ? AND role = 'signatory' LIMIT 1");
$sigInfoStmt->bind_param("s", $signatory);
$sigInfoStmt->execute();
$sigResult = $sigInfoStmt->get_result();
$signatoryData = $sigResult->fetch_assoc();

$current_sig_id = $signatoryData['id'] ?? 0;
$signatoryFullName = $signatoryData['full_name'] ?? $signatory;
$sig_type = strtolower($signatoryData['signatory_type'] ?? '');
$sig_dept = trim($signatoryData['department'] ?? '');

// Logic: Identify if restricted or global
$restricted_roles = ['adviser', 'program head', 'department head'];
$is_restricted = false;
foreach ($restricted_roles as $role) {
    if (strpos($sig_type, $role) !== false) {
        $is_restricted = true;
        break;
    }
}
$sigInfoStmt->close();

$fixed_doc_types = ["PDF (.pdf)", "Word (.docx)", "Excel (.xlsx)", "CSV (.csv)", "Image (.jpg)", "Image (.png)", "Text (.txt)", "ZIP (.zip)"];

// --- POST HANDLERS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'add_library') {
        $name = trim($_POST['new_requirement_name'] ?? '');
        if ($name !== '') {
            $chk = $conn->prepare("SELECT id FROM requirement_library WHERE requirement_name = ?");
            $chk->bind_param("s", $name);
            $chk->execute();
            if ($chk->get_result()->num_rows == 0) {
                $stmt = $conn->prepare("INSERT INTO requirement_library (requirement_name) VALUES (?)");
                $stmt->bind_param("s", $name);
                $stmt->execute();
            }
        }
    }

    if ($action === 'assign_requirement') {
        $no_req = isset($_POST['no_req_checkbox']);
        $req_id = $no_req ? 0 : intval($_POST['requirement_id'] ?? 0);
        $courses = $_POST['course_ids'] ?? [];
        $formats = $no_req ? 'N/A' : (isset($_POST['document_formats']) ? implode(', ', $_POST['document_formats']) : '');

        $assigned_count = 0;

        if (!empty($courses)) {
            foreach ($courses as $c_id) {
                // Check if admin already made a slot for this signatory+course
                $check = $conn->prepare("SELECT id FROM course_requirements WHERE course_id = ? AND signatory_id = ?");
                $check->bind_param("ii", $c_id, $current_sig_id);
                $check->execute();
                $existing = $check->get_result();
                $check->close();

                if ($existing->num_rows > 0) {
                    // Admin slot exists → UPDATE it with real requirement data and mark as configured
                    $stmt = $conn->prepare("UPDATE course_requirements SET requirement_id = ?, document_type_id = ?, requirements_configured = 1 WHERE course_id = ? AND signatory_id = ?");
                    $stmt->bind_param("isii", $req_id, $formats, $c_id, $current_sig_id);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    // No slot yet — signatory self-assigns (insert with configured = 1)
                    $stmt = $conn->prepare("INSERT INTO course_requirements (course_id, requirement_id, signatory_id, document_type_id, requirements_configured) VALUES (?, ?, ?, ?, 1)");
                    $stmt->bind_param("iiis", $c_id, $req_id, $current_sig_id, $formats);
                    $stmt->execute();
                    $stmt->close();
                }
                $assigned_count++;
            }
            echo "<script>alert('✅ Done! $assigned_count course(s) configured. Students can now see and comply.'); window.location.href='requirementssigna.php';</script>";
        }
    }
}

if (isset($_GET['delete_assign'])) {
    $stmt = $conn->prepare("DELETE FROM course_requirements WHERE id = ? AND signatory_id = ?");
    $stmt->bind_param("ii", $_GET['delete_assign'], $current_sig_id);
    $stmt->execute();
    header("Location: requirementssigna.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Requirements | Smart Clearance</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background: #f0f2f5; color: #1a1f36; overflow-x: hidden; }

        .home { position: absolute; top: 0; left: 260px; min-height: 100vh; width: calc(100% - 260px); transition: all 0.4s ease; padding: 40px; }
        nav.sidebar.close ~ .home { left: 88px; width: calc(100% - 88px); }

        .dashboard-header { margin-bottom: 35px; background: #fff; padding: 25px; border-radius: 16px; box-shadow: 0 2px 10px rgba(0,0,0,0.03); border-left: 6px solid #0b4e12; }
        .dashboard-header h1 { color: #0b4e12; font-size: 28px; font-weight: 700; }

        .management-grid { display: grid; grid-template-columns: 1fr 2fr; gap: 25px; margin-bottom: 35px; }
        .card-management { background: #fff; padding: 30px; border-radius: 20px; border: 1px solid #e3e8ee; box-shadow: 0 10px 15px rgba(0,0,0,0.05); }
        .card-management h3 { font-size: 18px; margin-bottom: 20px; color: #3c4257; display: flex; align-items: center; gap: 12px; font-weight: 600; }
        
        .form-group { margin-bottom: 20px; position: relative; }
        .form-group label { display: block; font-size: 14px; font-weight: 500; color: #4f566b; margin-bottom: 8px; }
        .input-style { width: 100%; height: 48px; padding: 0 16px; border: 2px solid #e3e8ee; border-radius: 12px; font-size: 15px; background: #fff; display: flex; align-items: center; color: #3c4257; }

        .dropdown-content { display: none; position: absolute; top: 100%; left: 0; width: 100%; background: #fff; border: 1px solid #e3e8ee; border-radius: 14px; z-index: 1000; box-shadow: 0 20px 25px rgba(0,0,0,0.1); max-height: 250px; overflow-y: auto; padding: 10px; }
        .dropdown-content.show { display: block; }
        .checkbox-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; cursor: pointer; border-radius: 10px; font-size: 14px; }
        .checkbox-item:hover { background: #f7fafc; }
        .checkbox-item.is-taken { opacity: 0.5; background: #fdfdfd; cursor: not-allowed; }

        .confirm-btn { background: #0b4e12; color: #fff; height: 50px; border-radius: 12px; border: none; cursor: pointer; font-weight: 600; width: 100%; transition: 0.3s; font-size: 16px; }
        .confirm-btn:hover { background: #083a0d; transform: translateY(-2px); }

        .no-req-card { background: #fff9e6; border: 1px solid #ffebad; padding: 16px; border-radius: 14px; margin-bottom: 25px; display: flex; align-items: center; gap: 12px; color: #856404; font-size: 14px; }
        .disabled-field { opacity: 0.4; pointer-events: none; filter: grayscale(1); }

        .table-container { background: #fff; border-radius: 20px; padding: 10px; border: 1px solid #e3e8ee; }
        .table { width: 100%; border-collapse: separate; border-spacing: 0; }
        .table th { background: #f9fafb; padding: 18px 20px; text-align: left; font-size: 12px; color: #4f566b; text-transform: uppercase; font-weight: 700; border-bottom: 2px solid #f0f2f5; }
        .table td { padding: 20px; border-bottom: 1px solid #f0f2f5; font-size: 15px; color: #3c4257; }
        
        .badge-format { background: #eef2ff; color: #4338ca; padding: 4px 10px; border-radius: 8px; font-size: 12px; font-weight: 600; border: 1px solid #e0e7ff; }
        .btn-delete { color: #a0aec0; font-size: 22px; transition: 0.2s; padding: 8px; }
        .btn-delete:hover { color: #e53e3e; background: #fff5f5; border-radius: 10px; }
    </style>
</head>
<body>
    
    <?php include 'sidebar_signa.php'; ?>

    <section class="home">
        <div class="dashboard-header">
            <h1>Requirement Settings</h1>
            <p>Role: <strong><?= ucwords($sig_type) ?></strong> | Scope: <strong><?= $is_restricted ? "Departmental (".htmlspecialchars($sig_dept).")" : "Global (All Courses)" ?></strong></p>
        </div>

        <div class="management-grid">
            <div class="card-management">
                <h3><i class='bx bx-bookmark-plus'></i> 1. Library</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="add_library">
                    <div class="form-group">
                        <label>Requirement Name</label>
                        <input type="text" name="new_requirement_name" class="input-style" placeholder="e.g. Student Journal" required>
                    </div>
                    <button type="submit" class="confirm-btn">Add to Library</button>
                </form>
            </div>

            <div class="card-management">
                <h3><i class='bx bx-task'></i> 2. Assignment</h3>
                <form method="POST" id="assignForm" onsubmit="return validateForm()">
                    <input type="hidden" name="action" value="assign_requirement">
                    
                    <div class="no-req-card">
                        <input type="checkbox" name="no_req_checkbox" id="noReqCheck" onchange="toggleNoReq(this)">
                        <label for="noReqCheck" style="cursor:pointer; font-weight: 600;">Skip physical file upload (No file required)</label>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group req-input-group">
                            <label>Requirement</label>
                            <select name="requirement_id" id="req_select" class="input-style" required>
                                <option value="">-- Choose --</option>
                                <?php 
                                $lib = $conn->query("SELECT * FROM requirement_library ORDER BY requirement_name ASC");
                                while($l = $lib->fetch_assoc()) echo "<option value='{$l['id']}'>".htmlspecialchars($l['requirement_name'])."</option>";
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Target Courses</label>
                            <div class="input-style dropdown-toggle" onclick="toggleLocalDropdown('courseDropdown')">
                                <span id="coursePlaceholder" style="color:#a0aec0;">Select Courses...</span>
                                <i class='bx bx-chevron-down' style="margin-left:auto;"></i>
                            </div>
                            <div id="courseDropdown" class="dropdown-content">
                                <label class="checkbox-item" style="border-bottom: 2px solid #f0f2f5; font-weight: bold; color: #0b4e12; margin-bottom: 5px;">
                                    <input type="checkbox" id="selectAllCourses" onchange="toggleSelectAll('courseDropdown', this)"> Select All Available
                                </label>

                                <?php 
                                // "Taken/Disabled" = signatory already configured this course (requirements_configured = 1)
                                // "Needs Setup" = admin assigned but signatory hasn't configured yet (requirements_configured = 0)
                                $existing_q = $conn->prepare("SELECT course_id, requirements_configured FROM course_requirements WHERE signatory_id = ?");
                                $existing_q->bind_param("i", $current_sig_id);
                                $existing_q->execute();
                                $existing_res = $existing_q->get_result();
                                $taken = [];        // already configured → disabled in dropdown
                                $pending_setup = []; // admin-assigned, not yet configured → selectable with badge
                                while($erow = $existing_res->fetch_assoc()) {
                                    if (intval($erow['requirements_configured']) === 1) {
                                        $taken[] = $erow['course_id'];
                                    } else {
                                        $pending_setup[] = $erow['course_id'];
                                    }
                                }
                                $existing_q->close();

                                $sql_c = "SELECT * FROM courses";
                                if($is_restricted && !empty($sig_dept)) {
                                    $depts = explode(',', $sig_dept);
                                    $conds = [];
                                    foreach($depts as $d) { $conds[] = "course_name LIKE '%".trim($d)."%'"; }
                                    $sql_c .= " WHERE " . implode(' OR ', $conds);
                                }
                                $crs = $conn->query($sql_c . " ORDER BY course_name ASC");
                                while($c = $crs->fetch_assoc()): 
                                    $is_taken   = in_array($c['id'], $taken);
                                    $is_pending = in_array($c['id'], $pending_setup);
                                ?>
                                    <label class="checkbox-item <?= $is_taken ? 'is-taken' : '' ?>" style="<?= $is_pending ? 'background:#fffbea; border-left:3px solid #f6ad55;' : '' ?>">
                                        <input type="checkbox" name="course_ids[]" value="<?= $c['id'] ?>" 
                                               data-name="<?= htmlspecialchars($c['course_name']) ?>" 
                                               <?= $is_taken ? 'disabled' : '' ?>
                                               onchange="updatePlaceholder('courseDropdown', 'coursePlaceholder', 'Select Courses...')">
                                        <?= htmlspecialchars($c['course_name']) ?>
                                        <?php if ($is_taken): ?>
                                            <small style="color:#e53e3e; margin-left:6px;">(Already Set)</small>
                                        <?php elseif ($is_pending): ?>
                                            <small style="color:#d97706; font-weight:700; margin-left:6px;"></small>
                                        <?php endif; ?>
                                    </label>
                                <?php endwhile; ?>
                            </div>
                        </div>

                        <div class="form-group req-input-group">
                            <label>Allowed Formats (Max 30MB)</label>
                            <div class="input-style dropdown-toggle" onclick="toggleLocalDropdown('formatDropdown')">
                                <span id="formatPlaceholder" style="color:#a0aec0;">Select Formats...</span>
                                <i class='bx bx-chevron-down' style="margin-left:auto;"></i>
                            </div>
                            <div id="formatDropdown" class="dropdown-content">
                                <?php foreach($fixed_doc_types as $f): ?>
                                    <label class="checkbox-item">
                                        <input type="checkbox" name="document_formats[]" value="<?= $f ?>" data-name="<?= $f ?>" onchange="updatePlaceholder('formatDropdown', 'formatPlaceholder', 'Select Formats...')">
                                        <?= $f ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div style="display: flex; align-items: flex-end; padding-bottom: 20px;">
                            <button type="submit" class="confirm-btn">Assign Now</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Requirement</th>
                        <th>Type & Limit</th>
                        <th>Course</th>
                        <th style="text-align:center;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt_list = $conn->prepare("SELECT cr.id, rl.requirement_name, cr.document_type_id, c.course_name FROM course_requirements cr LEFT JOIN requirement_library rl ON cr.requirement_id = rl.id JOIN courses c ON cr.course_id = c.id WHERE cr.signatory_id = ? AND cr.requirements_configured = 1 ORDER BY cr.id DESC");
                    $stmt_list->bind_param("i", $current_sig_id);
                    $stmt_list->execute();
                    $res_list = $stmt_list->get_result();
                    while($row = $res_list->fetch_assoc()): 
                        $no_file = ($row['document_type_id'] === 'N/A');
                    ?>
                        <tr>
                            <td style="font-weight:600;"><?= $row['requirement_name'] ?: '<span style="color:#d39e00;">System Approval Only</span>' ?></td>
                            <td>
                                <?php if(!$no_file): ?>
                                    <span class="badge-format"><?= htmlspecialchars($row['document_type_id']) ?></span>
                                    <small style="color: #c53030; font-weight: bold; margin-left: 5px;">30MB</small>
                                <?php else: ?>
                                    <span style="color:#cbd5e0;">---</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($row['course_name']) ?></td>
                            <td style="text-align:center;">
                                <a href="?delete_assign=<?= $row['id'] ?>" class="btn-delete" onclick="return confirm('Remove this assignment?')"><i class='bx bx-trash-alt'></i></a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </section>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const sidebar = document.querySelector('nav.sidebar');
            const toggle = document.querySelector(".toggle");
            if (toggle && sidebar) { toggle.addEventListener("click", () => sidebar.classList.toggle("close")); }
        });

        function toggleNoReq(checkbox) {
            const inputs = document.querySelectorAll('.req-input-group');
            const selectField = document.getElementById('req_select');
            if (checkbox.checked) {
                inputs.forEach(el => el.classList.add('disabled-field'));
                selectField.removeAttribute('required');
            } else {
                inputs.forEach(el => el.classList.remove('disabled-field'));
                selectField.setAttribute('required', 'required');
            }
        }

        function toggleLocalDropdown(id) {
            const dropdowns = document.querySelectorAll('.dropdown-content');
            dropdowns.forEach(d => { if(d.id !== id) d.classList.remove('show'); });
            document.getElementById(id).classList.toggle('show');
        }

        function updatePlaceholder(dropdownId, placeholderId, defaultText) {
            const container = document.getElementById(dropdownId);
            const selected = container.querySelectorAll('input[name="course_ids[]"]:checked, input[name="document_formats[]"]:checked');
            const display = document.getElementById(placeholderId);
            let names = Array.from(selected).map(cb => cb.getAttribute('data-name'));
            display.innerText = names.length > 0 ? names.join(', ') : defaultText;
            display.style.color = names.length > 0 ? "#3c4257" : "#a0aec0";
        }

        function toggleSelectAll(id, master) {
            const checkboxes = document.querySelectorAll(`#${id} input[type="checkbox"]:not(:disabled)`);
            checkboxes.forEach(cb => cb.checked = master.checked);
            updatePlaceholder(id === 'courseDropdown' ? 'courseDropdown' : 'formatDropdown', 
                              id === 'courseDropdown' ? 'coursePlaceholder' : 'formatPlaceholder', 
                              id === 'courseDropdown' ? 'Select Courses...' : 'Select Formats...');
        }

        function validateForm() {
            const noReq = document.getElementById('noReqCheck').checked;
            if(!noReq) {
                const courses = document.querySelectorAll('input[name="course_ids[]"]:checked');
                const formats = document.querySelectorAll('input[name="document_formats[]"]:checked');
                if(courses.length === 0) { alert('Please select at least one course.'); return false; }
                if(formats.length === 0) { alert('Please select at least one file format.'); return false; }
            }
            return true;
        }

        window.onclick = function(e) {
            if (!e.target.closest('.dropdown-toggle') && !e.target.closest('.dropdown-content')) {
                document.querySelectorAll('.dropdown-content').forEach(d => d.classList.remove('show'));
            }
        }
    </script>
</body>
</html>