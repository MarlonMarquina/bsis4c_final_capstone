<?php
// FILE: manage_signatories.php
include 'conn.php';
session_start();

// Authorization
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: login.php");
    exit();
}

$msg = '';
if (isset($_SESSION['message'])) {
    $msg = $_SESSION['message'];
    unset($_SESSION['message']);
}

// --- Dynamic Options ---
$departmentOptions = [];
$dept_query = $conn->query("SELECT DISTINCT course_name FROM courses ORDER BY course_name ASC");
if ($dept_query) {
    while ($row = $dept_query->fetch_assoc()) {
        if (!empty(trim($row['course_name']))) {
            $departmentOptions[] = trim($row['course_name']);
        }
    }
}
if (empty($departmentOptions)) $departmentOptions[] = 'No Courses Found';

// Fetch ACTUAL year/section combinations per course from students
$courseYearSections = [];
$student_query = $conn->query("
    SELECT DISTINCT u.course AS course_name, u.year, u.section 
    FROM users u
    INNER JOIN courses c ON u.course = c.course_name
    WHERE u.role = 'student' 
    AND u.year IS NOT NULL 
    AND u.year != '' 
    AND u.section IS NOT NULL 
    AND u.section != ''
    ORDER BY u.course, u.year, u.section
");

if ($student_query) {
    while ($row = $student_query->fetch_assoc()) {
        $course = trim($row['course_name']);
        $year = trim($row['year']);
        $section = trim($row['section']);
        
        if (!isset($courseYearSections[$course])) {
            $courseYearSections[$course] = [];
        }
        if (!isset($courseYearSections[$course][$year])) {
            $courseYearSections[$course][$year] = [];
        }
        if (!in_array($section, $courseYearSections[$course][$year])) {
            $courseYearSections[$course][$year][] = $section;
        }
    }
}

$signatoryOptions = ["Student Government (SG)", "Scholarship Office", "Class Adviser", "PTCA", "Research Office", "Program Head"];

// ========================================
// --- FETCH TAKEN ROLES FOR CONFLICT CHECK ---
// ========================================
$taken = [];
$programHeadDepts = []; // Track Program Head departments separately
$taken_q = $conn->query("SELECT signatory_type, department, year, section FROM users WHERE role='signatory'");
while ($r = $taken_q->fetch_assoc()) {
    $key = $r['signatory_type'];
    if ($key === 'Program Head') {
        // Program Head can have multiple departments (comma-separated)
        $depts = explode(',', trim($r['department'] ?? ''));
        foreach ($depts as $dept) {
            $dept = trim($dept);
            if (!empty($dept)) {
                $programHeadDepts[$dept] = true;
            }
        }
    } elseif ($key === 'Class Adviser') {
        // Class Adviser can have multiple year-section combinations
        // Format: year1|section1,year2|section2
        $department = trim($r['department'] ?? '');
        $combinations = explode(',', trim($r['section'] ?? ''));
        
        foreach ($combinations as $combo) {
            if (strpos($combo, '|') !== false) {
                list($year, $section) = explode('|', $combo);
                $key = "Class Adviser|{$department}|" . trim($year) . '|' . trim($section);
                $taken[$key] = true;
            }
        }
    } else {
        // Global roles
        $taken[$key] = true;
    }
}

// --- Add Signatory Handler ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_signatory'])) {
    $username = trim($_POST['username']);
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']); 
    $role = 'signatory';
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $signatory_type = trim($_POST['signatory_type']);
    $department = ''; 
    $year = ''; 
    $section = ''; 

    // Handle Program Head - Multiple Departments
    if ($signatory_type === 'Program Head') {
        if (isset($_POST['departments']) && is_array($_POST['departments'])) {
            $department = implode(',', array_map('trim', $_POST['departments']));
        }
        if (empty($department)) {
            $msg = "⚠️ Error: Pumili ng kahit isang department para sa Program Head.";
        }
    } 
    // Handle Class Adviser - Course, Year, Section (Multiple)
    elseif ($signatory_type === 'Class Adviser') {
if (isset($_POST['adviser_courses']) && is_array($_POST['adviser_courses'])) {
    $department = implode(',', array_map('trim', $_POST['adviser_courses']));
}        
        if (empty($department)) {
            $msg = "⚠️ Error: Pumili ng Course para sa Class Adviser.";
        } elseif (!isset($_POST['year_sections']) || !is_array($_POST['year_sections']) || empty($_POST['year_sections'])) {
            $msg = "⚠️ Error: Pumili ng kahit isang Year-Section para sa Class Adviser.";
        } else {
            // Store year-section combinations as comma-separated
            // Format: "1st Year|A,1st Year|B,2nd Year|A"
            $yearSections = array_map('trim', $_POST['year_sections']);
            
            // Check if any of the selected combinations are already taken
            $conflicts = [];
            foreach ($yearSections as $ys) {
                list($y, $s) = explode('|', $ys);
                $check_key = "Class Adviser|{$department}|{$y}|{$s}";
                if (isset($taken[$check_key])) {
                    $conflicts[] = "$y - $s";
                }
            }
            
            if (!empty($conflicts)) {
                $msg = "⚠️Already occupied: <strong>" . implode(', ', $conflicts) . "</strong>!";
            } else {
                // Store the first year-section for year/section columns
                list($year, $section) = explode('|', $yearSections[0]);
                
                // Store all combinations in section field
                // Format: year1|section1,year2|section2
                $section = implode(',', $yearSections);
            }
        }
    }

    // Proceed if no errors
    if (empty($msg)) {
        // Check Username/Email uniqueness
        $check = $conn->prepare("SELECT username FROM users WHERE username = ? OR email = ?"); 
        $check->bind_param("ss", $username, $email); 
        $check->execute();
        
        if ($check->get_result()->num_rows > 0) {
            $msg = "⚠️ Error: The email or username is already taken."; 
        } else {
            $insert = $conn->prepare("INSERT INTO users (username, full_name, email, year, section, password, role, signatory_type, department) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $insert->bind_param("sssssssss", $username, $full_name, $email, $year, $section, $password, $role, $signatory_type, $department);
            
            if ($insert->execute()) {
                $_SESSION['message'] = "✅ Signatory added successfully!";
                header("Location: manage_signatories.php");
                exit();
            } else {
                $msg = "❌ Error: " . $insert->error;
            }
        }
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM users WHERE id=$id AND role='signatory'");
    $_SESSION['message'] = "✅ Signatory deleted successfully!";
    header("Location: manage_signatories.php");
    exit();
}

$result = $conn->query("SELECT * FROM users WHERE role='signatory' ORDER BY full_name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Manage Signatories | Admin</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="styles.css"> 
    <style>
        body { 
            font-family: 'Poppins', sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 0;
        }
        .home { 
            position: relative; 
            left: 320px; 
            width: calc(100% - 320px); 
            transition: all 0.5s ease; 
            padding: 20px; 
            min-height: 100vh;
        }
        .sidebar.close ~ .home { 
            left: 88px; 
            width: calc(100% - 88px); 
        }
        .dashboard-container { 
            width: 95%; 
            margin: 20px auto; 
            background: #fff; 
            border-radius: 15px; 
            padding: 30px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.2); 
        }
        .dashboard-header { 
            background: linear-gradient(135deg, #2d5016 0%, #1a3409 100%);
            color: white; 
            padding: 20px; 
            border-radius: 12px; 
            text-align: center; 
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .dashboard-header h2 {
            margin: 0;
            font-size: 28px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .button-group { 
            display: flex; 
            gap: 15px; 
            margin-bottom: 25px; 
            flex-wrap: wrap;
        }
        .add-btn { 
            background: linear-gradient(135deg, #2d5016 0%, #1a3409 100%);
            color: white; 
            padding: 12px 25px; 
            border: none; 
            border-radius: 8px; 
            cursor: pointer; 
            font-weight: 600; 
            display: flex; 
            align-items: center; 
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(45, 80, 22, 0.3);
            text-decoration: none;
        }
        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(45, 80, 22, 0.4);
        }
        .add-btn i {
            font-size: 20px;
        }
        .import-btn {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
        }
        .import-btn:hover {
            box-shadow: 0 6px 20px rgba(0, 123, 255, 0.4);
        }
        
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        table th, table td { 
            padding: 15px; 
            border: 1px solid #e0e0e0; 
            text-align: center; 
        }
        table th { 
            background: linear-gradient(135deg, #2d5016 0%, #1a3409 100%);
            color: white; 
            font-weight: 600;
            text-transform: uppercase;
            font-size: 13px;
            letter-spacing: 0.5px;
        }
        table tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        table tr:hover {
            background-color: #e8f5e9;
            transition: background-color 0.3s ease;
        }
        .action-link {
            color: #2d5016;
            text-decoration: none;
            margin: 0 8px;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .action-link:hover {
            color: #1a3409;
            transform: scale(1.1);
        }
        .action-link.delete {
            color: #dc3545;
        }
        .action-link.delete:hover {
            color: #a71d2a;
        }
        
        .modal { 
            display: none; 
            position: fixed; 
            z-index: 1000; 
            left: 0; 
            top: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.5); 
            overflow-y: auto;
        }
        .modal-content { 
            background: white; 
            margin: 2% auto; 
            padding: 25px; 
            width: 420px; 
            max-width: 90%;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid #e0e0e0;
        }
        .modal-header h3 {
            margin: 0;
            color: #2d5016;
            font-size: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .close-modal {
            cursor: pointer;
            font-size: 24px;
            color: #999;
            transition: color 0.3s ease;
            background: none;
            border: none;
            padding: 0;
        }
        .close-modal:hover {
            color: #333;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 6px;
            color: #333;
            font-weight: 600;
            font-size: 13px;
        }
        .form-group label i {
            margin-right: 5px;
            color: #2d5016;
        }
        
        /* Password Input with Toggle */
        .password-wrapper {
            position: relative;
            display: flex;
            align-items: center;
        }
        .password-wrapper input {
            width: 100%;
            padding-right: 45px;
        }
        .password-toggle {
            position: absolute;
            right: 12px;
            cursor: pointer;
            color: #666;
            font-size: 18px;
            transition: color 0.3s ease;
        }
        .password-toggle:hover {
            color: #2d5016;
        }
        
        input, select, .submit-btn { 
            width: 100%; 
            padding: 10px 12px; 
            border-radius: 6px; 
            border: 2px solid #e0e0e0; 
            box-sizing: border-box;
            font-size: 13px;
            transition: all 0.3s ease;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #2d5016;
            box-shadow: 0 0 0 3px rgba(45, 80, 22, 0.1);
        }
        
        .submit-btn { 
            background: linear-gradient(135deg, #2d5016 0%, #1a3409 100%);
            color: white; 
            border: none; 
            font-weight: 600; 
            cursor: pointer;
            margin-top: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(45, 80, 22, 0.3);
        }
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(45, 80, 22, 0.4);
        }
        
        option:disabled { 
            color: #999; 
            font-style: italic; 
            background: #f5f5f5; 
        }
        
        .checkbox-group {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            padding: 12px;
            background: #f8f9fa;
            border-radius: 6px;
            border: 2px solid #e0e0e0;
            max-height: 300px;
            overflow-y: auto;
        }
        .checkbox-item {
            display: flex;
            align-items: center;
            padding: 6px;
            background: white;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        .checkbox-item:hover {
            background: #e8f5e9;
        }
        .checkbox-item input[type="checkbox"] {
            width: auto;
            margin-right: 8px;
            cursor: pointer;
            transform: scale(1.2);
        }
        .checkbox-item label {
            margin: 0;
            cursor: pointer;
            font-weight: 500;
            font-size: 13px;
        }
        .checkbox-item input[type="checkbox"]:disabled + label {
            color: #999;
            text-decoration: line-through;
        }
        
        .alert {
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideIn 0.3s ease;
        }
        @keyframes slideIn {
            from {
                transform: translateX(-20px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert i {
            font-size: 20px;
        }
    </style>
</head>
<body>

<?php 
    $admin_user = $_SESSION['username'];
    $admin_stmt = $conn->prepare("SELECT full_name FROM users WHERE username = ? AND role = 'admin'");
    $admin_stmt->bind_param("s", $admin_user);
    $admin_stmt->execute();
    $admin_res = $admin_stmt->get_result()->fetch_assoc();

    $signatoryFullName = !empty($admin_res['full_name']) ? $admin_res['full_name'] : $admin_user;
    $userRole = "Administrator"; 
    include 'sidebar_admin.php'; 
?>

<section class="home">
    <div class="dashboard-header">
        <h2><i class='bx bx-shield-alt-2'></i> MANAGE SIGNATORIES</h2>
    </div>
    
    <div class="dashboard-container">
        <?php if($msg): ?>
            <div class="alert <?= strpos($msg, '✅') !== false ? 'alert-success' : 'alert-warning' ?>">
                <i class='bx <?= strpos($msg, '✅') !== false ? 'bx-check-circle' : 'bx-error-circle' ?>'></i>
                <span><?= $msg ?></span>
            </div>
        <?php endif; ?>

        <div class="button-group">
            <button class="add-btn" onclick="openModal('addSignatoryModal')">
                <i class='bx bx-user-plus'></i> Add Signatory
            </button>
            <a href="signatories_import_form.php" class="add-btn import-btn">
                <i class='bx bx-upload'></i> Import Excel
            </a>
        </div>

        <table>
            <thead>
                <tr>
                    <th><i class='bx bx-user'></i> Full Name</th>
                    <th><i class='bx bx-briefcase'></i> Type</th>
                    <th><i class='bx bx-detail'></i> Assignment</th>
                    <th><i class='bx bx-cog'></i> Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['full_name']) ?></td>
                    <td><strong><?= htmlspecialchars($row['signatory_type']) ?></strong></td>
                    <td>
                        <?php 
                        $assign = [];
                        
                        if ($row['signatory_type'] === 'Class Adviser') {
                            // For Class Adviser, show course and all year-section combinations
                            if (!empty($row['department'])) {
                                $assign[] = "<i class='bx bx-building'></i> " . htmlspecialchars($row['department']);
                            }
                            
                            // Parse year-section combinations (stored as: year1|section1,year2|section2)
                            if (!empty($row['section'])) {
                                $combinations = explode(',', $row['section']);
                                $yearSections = [];
                                foreach ($combinations as $combo) {
                                    if (strpos($combo, '|') !== false) {
                                        list($y, $s) = explode('|', $combo);
                                        $yearSections[] = "$y-$s";
                                    }
                                }
                                if (!empty($yearSections)) {
                                    $assign[] = "<i class='bx bx-calendar'></i> " . implode(', ', $yearSections);
                                }
                            }
                        } else {
                            // For other roles, show normally
                            if(!empty($row['department'])) $assign[] = "<i class='bx bx-building'></i> ".$row['department'];
                            if(!empty($row['year'])) $assign[] = "<i class='bx bx-calendar'></i> ".$row['year'];
                            if(!empty($row['section']) && $row['signatory_type'] !== 'Class Adviser') $assign[] = "<i class='bx bx-group'></i> ".$row['section'];
                        }
                        
                        echo !empty($assign) ? implode(' | ', $assign) : '<i class="bx bx-world"></i> Global';
                        ?>
                    </td>
                    <td>
                        <a href="edit_signatory.php?id=<?= $row['id'] ?>" class="action-link">
                            <i class='bx bx-edit-alt'></i> Edit
                        </a>
                        <a href="manage_signatories.php?delete=<?= $row['id'] ?>" class="action-link delete" onclick="return confirm('Delete this signatory?')">
                            <i class='bx bx-trash'></i> Delete
                        </a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</section>

<div id="addSignatoryModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class='bx bx-user-plus'></i> Add New Signatory</h3>
            <button class="close-modal" onclick="closeModal('addSignatoryModal')">&times;</button>
        </div>
        
        <form method="POST" id="signatoryForm">
            <div class="form-group">
                <label><i class='bx bx-user'></i> Full Name</label>
                <input type="text" name="full_name" placeholder="Enter full name" required>
            </div>

            <div class="form-group">
                <label><i class='bx bx-id-card'></i> Username</label>
                <input type="text" name="username" placeholder="Enter username" required>
            </div>
            
            <div class="form-group">
                <label><i class='bx bx-envelope'></i> Email</label>
                <input type="email" name="email" placeholder="Enter email address" required>
            </div>

            <div class="form-group">
                <label><i class='bx bx-lock'></i> Password</label>
                <div class="password-wrapper">
                    <input type="password" name="password" id="passwordInput" placeholder="Enter password" required>
                    <i class='bx bx-hide password-toggle' id="togglePassword" onclick="togglePasswordVisibility()"></i>
                </div>
            </div>

            <div class="form-group">
                <label><i class='bx bx-briefcase'></i> Signatory Type</label>
                <select name="signatory_type" id="mainType" onchange="handleTypeChange()" required>
                    <option value="">-- Select Signatory Type --</option>
                    <?php foreach($signatoryOptions as $opt): 
                        $disabled = (isset($taken[$opt]) && $opt !== 'Program Head' && $opt !== 'Class Adviser') ? 'disabled' : '';
                    ?>
                        <option value="<?= $opt ?>" <?= $disabled ?>>
                            <?= $opt ?><?= $disabled ? ' ✖ (Occupied)' : '' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- For Program Head - Multiple Departments -->
            <div id="programHeadContainer" style="display:none;">
                <div class="form-group">
                    <label><i class='bx bx-building-house'></i> Select Departments (Pwedeng Multiple)</label>
                    <div class="checkbox-group">
                        <?php foreach($departmentOptions as $d): 
                            $isOccupied = isset($programHeadDepts[$d]);
                        ?>
                            <div class="checkbox-item">
                                <input type="checkbox" 
                                       name="departments[]" 
                                       value="<?= $d ?>" 
                                       id="dept_<?= md5($d) ?>"
                                       <?= $isOccupied ? 'disabled' : '' ?>>
                                <label for="dept_<?= md5($d) ?>">
                                    <?= $d ?><?= $isOccupied ? ' (Occupied)' : '' ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- For Class Adviser -->
            <div id="adviserExtras" style="display:none;">
               <div class="form-group">
    <label><i class='bx bx-building'></i> Select Courses (Multiple)</label>
    <div class="checkbox-group">
        <?php foreach($departmentOptions as $d): ?>
            <div class="checkbox-item">
                <input type="checkbox" name="adviser_courses[]" value="<?= $d ?>" class="adviser-course-check" onchange="updateAdviserYearSections()">
                <label><?= $d ?></label>
            </div>
        <?php endforeach; ?>
    </div>
</div>

                <div class="form-group" id="yearSectionCheckboxContainer" style="display:none;">
                    <label><i class='bx bx-calendar'></i> Select Year Level & Sections (Pwedeng Multiple)</label>
                    <div id="yearSectionCheckboxes" class="checkbox-group">
                        <!-- Dynamically populated via JavaScript -->
                    </div>
                </div>
            </div>

            <button type="submit" name="add_signatory" class="submit-btn">
                <i class='bx bx-check-circle'></i> Save Signatory
            </button>
        </form>
    </div>
</div>

<script>
const takenAssignments = <?= json_encode($taken) ?>;
const courseYearSections = <?= json_encode($courseYearSections) ?>;

function openModal(id) { 
    document.getElementById(id).style.display = 'block'; 
}

function closeModal(id) { 
    document.getElementById(id).style.display = 'none';
}

function togglePasswordVisibility() {
    const passwordInput = document.getElementById('passwordInput');
    const toggleIcon = document.getElementById('togglePassword');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('bx-hide');
        toggleIcon.classList.add('bx-show');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('bx-show');
        toggleIcon.classList.add('bx-hide');
    }
}

function handleTypeChange() {
    const type = document.getElementById('mainType').value;
    const programHeadContainer = document.getElementById('programHeadContainer');
    const adviserExtras = document.getElementById('adviserExtras');
    
    programHeadContainer.style.display = (type === 'Program Head') ? 'block' : 'none';
    adviserExtras.style.display = (type === 'Class Adviser') ? 'block' : 'none';
    
    // Reset Class Adviser fields
    if (type === 'Class Adviser') {
        document.getElementById('adviserCourseSel').value = '';
        document.getElementById('yearSectionCheckboxContainer').style.display = 'none';
        document.getElementById('yearSectionCheckboxes').innerHTML = '';
    }
}

function updateAdviserYearSections() {
    // 1. Hanapin lahat ng kurso na nilagyan mo ng check
    const checkedCourses = Array.from(document.querySelectorAll('.adviser-course-check:checked')).map(cb => cb.value);
    const container = document.getElementById('yearSectionCheckboxContainer');
    const checkboxesDiv = document.getElementById('yearSectionCheckboxes');
    
    checkboxesDiv.innerHTML = ''; // Linisin muna ang listahan
    
    // 2. Kung walang naka-check na kurso, itago ang section list
    if (checkedCourses.length === 0) {
        container.style.display = 'none';
        return;
    }
    
    container.style.display = 'block';
    
    // 3. Loop sa bawat kursong pinili mo (e.g. BSIS, ACT)
    checkedCourses.forEach(course => {
        if (courseYearSections[course]) {
            const years = Object.keys(courseYearSections[course]).sort();
            
            years.forEach(year => {
                courseYearSections[course][year].forEach(section => {
                    // Isama ang Course Name sa value para ma-save sa database nang tama
                    const val = `${course}|${year}|${section}`;
                    const isOccupied = takenAssignments[`Class Adviser|${val}`];
                    const uniqueId = `ys_${btoa(val).replace(/=/g, '')}`;
                    
                    const div = document.createElement('div');
                    div.className = 'checkbox-item';
                    div.innerHTML = `
                        <input type="checkbox" name="year_sections[]" value="${val}" id="${uniqueId}" ${isOccupied ? 'disabled' : ''}>
                        <label for="${uniqueId}">
                            <strong>[${course}]</strong> ${year} - ${section} ${isOccupied ? '(Occupied)' : ''}
                        </label>
                    `;
                    checkboxesDiv.appendChild(div);
                });
            });
        }
    });
}
window.onclick = function(event) {
    if (event.target.className === 'modal') {
        event.target.style.display = "none";
    }
}
</script>
</body>
</html>