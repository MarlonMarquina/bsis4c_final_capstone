-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: db5019018582.hosting-data.io
-- Generation Time: Jan 27, 2026 at 07:36 AM
-- Server version: 10.11.14-MariaDB-log
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbs14970408`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `announcement_reads`
--

CREATE TABLE `announcement_reads` (
  `id` int(11) NOT NULL,
  `announcement_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `read_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement_reads`
--

INSERT INTO `announcement_reads` (`id`, `announcement_id`, `username`, `read_at`) VALUES
(9, 5, 'student', '2025-11-08 22:46:59'),
(10, 6, 'student1', '2025-11-09 11:56:00');

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `signatory` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `document` varchar(255) NOT NULL,
  `status` enum('Pending','Approved','Requires Action') DEFAULT 'Pending',
  `rejection_reason` text DEFAULT NULL,
  `require_resubmit` tinyint(1) DEFAULT 0,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` datetime DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `rejection_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`id`, `username`, `signatory`, `course`, `document`, `status`, `rejection_reason`, `require_resubmit`, `submitted_at`, `reviewed_at`, `remarks`, `rejection_count`) VALUES
(102, 'MA22014141', 'annesantos', 'Bachelor of Science in Office Mangement(BSOM)', '553495368_1088254003071117_1391113352270904610_n__1__1763605769.png', 'Pending', NULL, 0, '2025-11-20 02:32:04', NULL, NULL, 0),
(103, 'MA22014141', 'melodydejesus', 'Bachelor of Science in Office Mangement(BSOM)', '553495368_1088254003071117_1391113352270904610_n__1__1763605867.png', 'Approved', NULL, 0, '2025-11-20 02:32:04', '2025-11-19 22:19:43', NULL, 0),
(104, 'MA22014141', 'melodydejesus', 'Bachelor of Science in Office Mangement(BSOM)', 'N/A', '', NULL, 0, '2025-11-20 02:32:04', '2025-11-19 21:32:59', 'Absent', 1),
(105, 'MA22013030', 'marissa', 'Computer Secretarial', 'N/A', '', NULL, 0, '2025-11-20 03:26:37', '2025-11-19 22:29:51', 'hhhh', 1),
(106, 'MA22013030', 'marissa', 'Computer Secretarial', 'N/A', '', NULL, 0, '2025-11-20 03:41:33', '2025-11-19 22:42:17', 'bawal', 1),
(107, 'MA22013030', 'marissa', 'Computer Secretarial', 'N/A', '', 'gyrtr', 0, '2025-11-20 03:45:49', '2025-11-19 22:58:32', 'gyrtr', 2),
(108, 'MA2201010', 'marissa', 'Contact Center Services (NC II)', '553495368_1088254003071117_1391113352270904610_n__1__1763610745.png', 'Approved', NULL, 0, '2025-11-20 03:52:33', '2025-11-19 22:53:06', NULL, 0),
(109, 'MA2201010', 'marissa', 'Contact Center Services (NC II)', '553495368_1088254003071117_1391113352270904610_n__1__1763611255.png', 'Approved', NULL, 0, '2025-11-20 04:01:00', '2025-11-19 23:01:37', NULL, 0),
(110, 'MA22013737', 'paulovictoria', 'Bachelor of Science in Information System (BSIS)', 'N/A', '', 'jjjjjjjj', 0, '2025-11-20 04:07:51', '2025-11-19 23:09:43', 'jjjjjjjj', 1),
(111, 'MA22013737', 'paulovictoria', 'Bachelor of Science in Information System (BSIS)', '553495368_1088254003071117_1391113352270904610_n__1__1763611255_1763611664.png', 'Requires Action', 'aaaaaaaa', 0, '2025-11-20 04:07:51', '2025-11-19 23:09:26', 'aaaaaaaa', 1),
(112, 'MA11111111', 'jj', 'Associate in Computer Technology (Ladderized to BSIS).', 'IS-EBP_Reviewer_1763615700.pdf', 'Approved', NULL, 0, '2025-11-20 05:17:03', '2025-11-20 00:17:23', NULL, 0),
(113, 'MA124', 'annesantos', 'Bachelor of Science in Information System (BSIS)', 'N/A', 'Approved', NULL, 0, '2025-11-20 05:17:26', '2025-11-20 00:29:10', NULL, 0),
(114, 'MA124', 'paulovictoria', 'Bachelor of Science in Information System (BSIS)', '553495368_1088254003071117_1391113352270904610_n_1763615821.png', 'Requires Action', 'retwfdtwfdyw', 0, '2025-11-20 05:31:50', '2025-11-20 00:36:28', 'retwfdtwfdyw', 1),
(115, 'MA11111111', 'jj', 'Associate in Computer Technology (Ladderized to BSIS).', 'IS-EBP_Reviewer_RESUBMITTED_1763617522.pdf', 'Approved', NULL, 0, '2025-11-20 05:45:22', '2025-11-20 00:45:42', 'djfiosf', 0);

-- --------------------------------------------------------

--
-- Table structure for table `clearance_requests`
--

CREATE TABLE `clearance_requests` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `course` varchar(100) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `remarks` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clearance_requirements`
--

CREATE TABLE `clearance_requirements` (
  `id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `signatory_id` int(11) NOT NULL,
  `requirement_name` varchar(255) NOT NULL,
  `status` enum('Pending','Completed') NOT NULL DEFAULT 'Pending',
  `file` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_name`) VALUES
(26, 'Associate in Computer Technology (Ladderized to BSIS).'),
(18, 'Bachelor of Science in Information System (BSIS)'),
(5, 'Bachelor of Science in Office Mangement(BSOM)'),
(7, 'Bachelor of Technical-Vocational Teacher Education (BTVTED)'),
(13, 'Book - Keeping NC (III)'),
(23, 'Computer Secretarial'),
(14, 'Contact Center Services (NC II)'),
(11, 'Diplomat in Hotel and Restaurant Management Technology (DHRMT)'),
(15, 'Electrical Installation and Maintenance (NC II)'),
(10, 'Hotel and Restaurant Services (HRS)'),
(16, 'Shielded Metal Arc Welding (NC I & NC II)');

-- --------------------------------------------------------

--
-- Table structure for table `course_requirements`
--

CREATE TABLE `course_requirements` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `requirement_id` int(11) NOT NULL,
  `signatory_id` int(11) DEFAULT NULL,
  `document_type` varchar(50) NOT NULL,
  `document_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_requirements`
--

INSERT INTO `course_requirements` (`id`, `course_id`, `requirement_id`, `signatory_id`, `document_type`, `document_type_id`) VALUES
(66, 7, 19, NULL, '', 15),
(67, 7, 19, NULL, '', 15),
(68, 7, 19, NULL, '', 15),
(71, 10, 19, NULL, '', 15),
(72, 10, 19, NULL, '', 15),
(78, 15, 19, NULL, '', 15),
(79, 15, 19, NULL, '', 15),
(83, 5, 19, 92, '', 15),
(84, 5, 13, 98, '', 16),
(85, 5, 17, 92, '', 16),
(88, 23, 19, 97, '', 15),
(89, 23, 17, 97, '', 16),
(90, 14, 17, 97, '', 16),
(92, 18, 17, 86, '', 16),
(93, 18, 13, 98, '', 16),
(94, 26, 28, 105, '', 1),
(95, 18, 19, 98, '', 15),
(96, 26, 17, 105, '', 16);

-- --------------------------------------------------------

--
-- Table structure for table `document_types`
--

CREATE TABLE `document_types` (
  `id` int(11) NOT NULL,
  `type_name` varchar(100) NOT NULL,
  `extensions` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `document_types`
--

INSERT INTO `document_types` (`id`, `type_name`, `extensions`, `note`, `created_at`) VALUES
(1, 'PDF', 'pdf', 'Adobe PDF', '2025-11-14 21:36:01'),
(2, 'DOCX', 'docx,doc', 'Word documents', '2025-11-14 21:36:02'),
(15, 'no file', '', '(no file required)', '2025-11-17 20:41:57'),
(16, 'Picture', 'png', '', '2025-11-17 20:45:50'),
(19, 'document', 'docx', 'docx', '2025-11-19 01:44:12'),
(20, 'excel', 'xlsx', '', '2025-11-19 20:13:19'),
(21, 'dsdfdsfds', 'fsdfsd', 'sdfsdf', '2025-11-20 00:06:37');

-- --------------------------------------------------------

--
-- Table structure for table `draft_requirements`
--

CREATE TABLE `draft_requirements` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `requirement_id` int(11) NOT NULL,
  `signatory_id` int(11) DEFAULT NULL,
  `document_type_id` int(11) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `draft_requirements`
--

INSERT INTO `draft_requirements` (`id`, `username`, `requirement_id`, `signatory_id`, `document_type_id`, `file_name`, `created_at`) VALUES
(88, 'MA123455', 19, NULL, 15, NULL, '2025-11-19 01:13:42'),
(102, 'MA123', 19, NULL, 15, NULL, '2025-11-19 09:14:31'),
(112, 'MA123', 19, NULL, 15, NULL, '2025-11-19 16:53:07');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(50) NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `username`, `message`, `type`, `is_read`, `created_at`) VALUES
(43, 'MA12345', 'Your application (ID: 56) was **Returned** by Signatory: paulovictoria. Please **Resubmit** a revised document. Reason: MALI PINASA MO', 'danger', 0, '2025-11-16 23:44:51'),
(44, 'MA12345', 'Your application (ID: 56) has been **Approved** by Signatory: paulovictoria. You are now cleared for this requirement.', 'success', 0, '2025-11-16 23:47:09'),
(45, 'MA2468', 'Your application (ID: 60) has been **Approved** by Signatory: russeldustinbegelia. You are now cleared for this requirement.', 'success', 0, '2025-11-17 00:33:58'),
(46, 'MA2468', 'Your application (ID: 61) was **Returned** by Signatory: russeldustinbegelia. Please **Resubmit** a revised document. Reason: knkn', 'danger', 0, '2025-11-17 00:34:22'),
(47, 'MA2468', 'Your application (ID: 62) was **Returned** by Signatory: russeldustinbegelia. Please **Resubmit** a revised document. Reason: ikaw pa galet????? ako na ang masama ikaw ang mabuti??', 'danger', 0, '2025-11-17 21:25:27'),
(48, 'MA12345', 'Your application (ID: 63) has been **Approved** by Signatory: russeldustinbegelia. You are now cleared for this requirement.', 'success', 0, '2025-11-17 21:25:33'),
(49, 'MA2468', 'Your application (ID: 62) was **Rejected** (Final) and is now closed. Reason: thtrhr', 'danger', 0, '2025-11-17 21:26:21'),
(50, 'MA12345', 'Your application (ID: 69) has been **Approved** by Signatory: Anthony. You are now cleared for this requirement.', 'success', 0, '2025-11-18 04:47:46'),
(51, 'MA12345', 'Your application (ID: 74) has been **Approved** by Signatory: irishcalayag. You are now cleared for this requirement.', 'success', 0, '2025-11-18 04:57:10'),
(52, 'MA12345', 'Your application (ID: 72) has been **Approved** by Signatory: irishcalayag. You are now cleared for this requirement.', 'success', 0, '2025-11-18 04:57:14'),
(53, 'MA12345', 'Your application (ID: 71) has been **Approved** by Signatory: irishcalayag. You are now cleared for this requirement.', 'success', 0, '2025-11-18 04:57:17'),
(54, 'MA12345', 'Your application (ID: 70) has been **Approved** by Signatory: irishcalayag. You are now cleared for this requirement.', 'success', 0, '2025-11-18 04:57:20'),
(55, 'MA12345', 'Your application (ID: 68) was **Returned** by Signatory: irishcalayag. Please **Resubmit** a revised document. Reason: Pangit ka kasi', 'danger', 0, '2025-11-18 04:57:50'),
(56, 'MA12345', 'Your application (ID: 75) was **Returned** by Signatory: Anthony. Please **Resubmit** a revised document. Reason: hfeefejf', 'danger', 0, '2025-11-18 11:56:22'),
(57, 'MA12345', 'Your application (ID: 73) has been **Approved** by Signatory: Anthony. You are now cleared for this requirement.', 'success', 0, '2025-11-18 11:56:29'),
(58, 'MA2468', 'Your application (ID: 61) has been **Approved** by Signatory: russeldustinbegelia. You are now cleared for this requirement.', 'success', 0, '2025-11-18 12:06:33'),
(59, 'MA12345', 'Your application (ID: 78) has been **Approved** by Signatory: russeldustinbegelia. You are now cleared for this requirement.', 'success', 0, '2025-11-18 12:07:45'),
(60, 'MA12344', 'Your application (ID: 79) has been **Approved** by Signatory: russeldustinbegelia. You are now cleared for this requirement.', 'success', 0, '2025-11-18 12:09:21'),
(61, 'MA12345', 'Your application (ID: 80) has been **Approved** by Signatory: russeldustinbegelia. You are now cleared for this requirement.', 'success', 0, '2025-11-18 19:07:38'),
(62, 'MA00000', 'Your application (ID: 81) has been **Approved** by Signatory: marie. You are now cleared for this requirement.', 'success', 0, '2025-11-18 23:11:46'),
(63, 'gab', 'Your application (ID: 86) was **Returned** by Signatory: marlon. Please **Resubmit** a revised document. Reason: .', 'danger', 0, '2025-11-19 06:44:29'),
(64, 'gab', 'Your application (ID: 86) was **Rejected** (Final) and is now closed. Reason: .', 'danger', 0, '2025-11-19 06:51:48'),
(65, 'gab', 'Your application (ID: 87) has been **Approved** by Signatory: Jerome. You are now cleared for this requirement.', 'success', 0, '2025-11-19 08:47:27'),
(66, 'MA123', 'Your application (ID: 90) was **Returned** by Signatory: Jerome. Please **Resubmit** a revised document. Reason: RESUBMIT 2 DOCX', 'danger', 0, '2025-11-19 08:48:09'),
(67, 'gab', 'Your application (ID: 82) has been **Approved** (Bulk Action) by Signatory: mark.', 'success', 0, '2025-11-19 08:55:40'),
(68, 'MA123', 'Your application (ID: 89) has been **Approved** (Bulk Action) by Signatory: mark.', 'success', 0, '2025-11-19 08:55:40'),
(69, 'MA123', 'Your application (ID: 91) was **Returned** by Signatory: marlon. Please **Resubmit** a revised document. Reason: ABSENT', 'danger', 0, '2025-11-19 09:06:32'),
(70, 'MA123', 'Your application (ID: 92) was **Rejected** (Final) and is now closed. Reason: ABSENT', 'danger', 0, '2025-11-19 09:10:41'),
(71, 'MA2025', 'Your application (ID: 98) has been **Approved** by Signatory: Irish. You are now cleared for this requirement.', 'success', 0, '2025-11-19 10:56:13'),
(72, 'MA0909', 'Your application (ID: 94) has been **Approved** by Signatory: marlon. You are now cleared for this requirement.', 'success', 0, '2025-11-19 11:29:22'),
(73, 'MA22014141', 'Your application (ID: 104) was **Rejected** (Final) and is now closed. Reason: Absent', 'danger', 0, '2025-11-19 21:32:59'),
(74, 'MA22014141', 'Your application (ID: 103) has been **Approved** by Signatory: melodydejesus. You are now cleared for this requirement.', 'success', 0, '2025-11-19 22:19:43'),
(75, 'MA22013030', 'Your application (ID: 105) was **Rejected** (Final) and is now closed. Reason: hhhh', 'danger', 0, '2025-11-19 22:29:51'),
(76, 'MA22013030', 'Your application (ID: 106) was **Rejected** (Final) and is now closed. Reason: bawal', 'danger', 0, '2025-11-19 22:42:17'),
(77, 'MA22013030', 'Your application (ID: 107) was **Returned** by Signatory: marissa. Please **Resubmit** a revised document. Reason: uuuuu', 'danger', 0, '2025-11-19 22:46:31'),
(78, 'MA2201010', 'Your application (ID: 108) has been **Approved** by Signatory: marissa. You are now cleared for this requirement.', 'success', 0, '2025-11-19 22:53:06'),
(79, 'MA22013030', 'Your application (ID: 107) was **Rejected** (Final) and is now closed. Reason: gyrtr', 'danger', 0, '2025-11-19 22:58:32'),
(80, 'MA2201010', 'Your application (ID: 109) has been **Approved** (Bulk Action) by Signatory: marissa.', 'success', 0, '2025-11-19 23:01:37'),
(81, 'MA22013737', 'Your application (ID: 111) was **Returned** by Signatory: paulovictoria. Please **Resubmit** a revised document. Reason: aaaaaaaa', 'warning', 0, '2025-11-19 23:09:26'),
(82, 'MA22013737', 'Your application (ID: 110) was **Rejected** (Final) and is now closed. Reason: jjjjjjjj', 'danger', 0, '2025-11-19 23:09:43'),
(83, 'MA11111111', 'Your application (ID: 112) has been **Approved** by Signatory: jj. You are now cleared for this requirement.', 'success', 0, '2025-11-20 00:17:23'),
(84, 'MA124', 'Your application (ID: 113) has been **Approved** by Signatory: annesantos. You are now cleared for this requirement.', 'success', 0, '2025-11-20 00:29:10'),
(85, 'MA124', 'Your application (ID: 114) was **Returned** by Signatory: paulovictoria. Please **Resubmit** a revised document. Reason: retwfdtwfdyw', 'warning', 0, '2025-11-20 00:36:28'),
(86, 'MA11111111', 'Your application (ID: 115) was **Returned** by Signatory: jj. Please **Resubmit** a revised document. Reason: djfiosf', 'warning', 0, '2025-11-20 00:44:56'),
(87, 'MA11111111', 'Your application (ID: 115) has been **Approved** by Signatory: jj. You are now cleared for this requirement.', 'success', 0, '2025-11-20 00:45:42');

-- --------------------------------------------------------

--
-- Table structure for table `requirement_library`
--

CREATE TABLE `requirement_library` (
  `id` int(11) NOT NULL,
  `requirement_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requirement_library`
--

INSERT INTO `requirement_library` (`id`, `requirement_name`) VALUES
(13, 'screenshot of gform'),
(17, 'Pictrure'),
(19, 'no file required'),
(28, 'Submit Form');

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `year` varchar(50) NOT NULL,
  `section_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `course_id`, `year`, `section_name`) VALUES
(13, 0, '', 'B'),
(26, 5, '1st Year', 'A'),
(15, 5, '4th Year', 'A'),
(16, 5, '4th Year', 'B'),
(14, 7, '1st Year', 'A'),
(27, 10, '4th Year', 'A'),
(19, 13, '4th Year', 'A'),
(37, 14, '1st Year', 'A'),
(29, 15, '4th Year', 'A'),
(21, 18, '1st Year', 'A'),
(31, 18, '1st Year', 'B'),
(22, 18, '2nd Year', 'A'),
(32, 18, '2nd Year', 'B'),
(33, 18, '3rd Year', 'A'),
(34, 18, '3rd Year', 'B'),
(20, 18, '4th Year', 'A'),
(35, 18, '4th Year', 'B'),
(17, 20, '4th Year', 'A'),
(18, 20, '4th Year', 'B'),
(36, 23, '4th Year', 'A'),
(28, 24, '4th Year', 'A'),
(30, 25, '1st Year', 'A'),
(38, 26, '1st Year', 'A'),
(39, 26, '1st Year', 'B'),
(40, 26, '2nd Year', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `enrollment_status` varchar(50) DEFAULT NULL,
  `course_section` varchar(50) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `full_name` varchar(150) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `year` varchar(20) DEFAULT NULL,
  `section` varchar(50) DEFAULT NULL,
  `adviser_username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','signatory','admin','sg_officer') NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `signatory_type` varchar(100) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `full_name`, `sex`, `email`, `course_id`, `year`, `section`, `adviser_username`, `password`, `role`, `profile_pic`, `signatory_type`, `department`, `course`, `student_id`, `birthdate`, `contact`, `street`, `city`, `province`) VALUES
(85, 'adminkaren', 'Karen-Ann Rose Payumo', NULL, 'clearancebpc@gmail.com', NULL, NULL, NULL, NULL, '$2y$10$MORo3BfLcccQNdcZIFWrcejXaeCwPuVERJ0Vn.J3j5Mnht/AxRwqm', 'admin', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(86, 'paulovictoria', 'Paulo Victoria, MIT', NULL, 'paulo@yahoo.com', NULL, '', '', NULL, '$2y$10$J0lNs127vAvn5t4xhcVri..b7mbETxq.wS5hqJBB2Drrue4KboS1O', 'signatory', NULL, 'Program Head', 'Bachelor of Science in Information System (BSIS)', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(89, 'MA22014141', 'Irish Calayag', NULL, 'irishangelcalayag@gmail.com', NULL, '4th Year', 'A', NULL, '$2y$10$vDFlJ8KgRNiB4e8SqAGOJuRgd/BcflJG5Gw1uEm9GuOrtiQ0rbzj6', 'student', NULL, '', '', 'Bachelor of Science in Office Mangement(BSOM)', NULL, NULL, NULL, NULL, NULL, NULL),
(91, 'MA22013737', 'Russel Begelia', NULL, 'russel.begelia@bpc.edu.ph', NULL, '4th Year', 'A', NULL, '$2y$10$9sqLLzev4YY9BQr6rfEGDuQR.q/n5vzBjTJyizRhCVKwSllIsZ1pq', 'student', NULL, '', '', 'Bachelor of Science in Information System (BSIS)', NULL, NULL, NULL, NULL, NULL, NULL),
(92, 'melodydejesus', 'Melody De Jesus, MM.', NULL, 'melody@yahoo.com', NULL, '', '', NULL, '$2y$10$1PrylOQ/jYTVDugCDvUPq.vq5eB/6heZs9BXVPS9eDAulWJ4D9nq6', 'signatory', NULL, 'Program Head', 'Bachelor of Science in Office Mangement(BSOM)', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(95, 'eliseo', 'Dr. Eliseo Amaninche', NULL, 'eliseo@yahoo.com', NULL, '', '', NULL, '$2y$10$hsRnL9Txt9pFmsJgvs9bLeNwN3pR3ft/mXDX3jg6VRitmC7SuZyAi', 'signatory', NULL, 'Program Head', 'Bachelor of Technical-Vocational Teacher Education', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(96, 'meloliver', 'Dr. Mel Oliver Balagtas', NULL, 'meloliver@yahoo.com', NULL, '', '', NULL, '$2y$10$TPatJ90cxyEp.28lEpgkBOt.amdWfyVPbV5uKUa0pqcM79MYCMi5S', 'signatory', NULL, 'Program Head', 'Hotel and Restaurant Services (HRS)', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(97, 'marissa', 'Marissa Menoza, LPT, MSS', NULL, 'marissa@yahoo.com', NULL, '', '', NULL, '$2y$10$Ma1hTHmJ45u1mK0Eei6NNOqaDl4t1THzQmEjsZEQQcfCtotaS8d5i', 'signatory', NULL, 'Student Government (SG)', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(98, 'annesantos', 'Anne Santos, MBA', NULL, 'anne@yahoo.com', NULL, '', '', NULL, '$2y$10$psW7ToI5xZo1Cm.ab/O9bezG6eSmk4Zchykkr28BhOpnXyMhyyK8e', 'signatory', NULL, 'Scholarship Office', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(99, 'MA22013030', 'Vince Abra', NULL, 'vince@gmail.com', NULL, '4th Year', 'A', NULL, '$2y$10$Rp2f1mXEcaHGhFev89at/Odatoc262gKroko1rSfV7eQyr6YcZdEq', 'student', NULL, '', '', 'Computer Secretarial', NULL, NULL, NULL, NULL, NULL, NULL),
(100, 'MA2201010', 'Mark ant', NULL, 'markant@gmail.com', NULL, '1st Year', 'A', NULL, '$2y$10$B02ZKt751dK4YBZKGFN.qu7Xe4Fmld8tfFOJrXIwlTBGQqFO1GLQG', 'student', NULL, '', '', 'Contact Center Services (NC II)', NULL, NULL, NULL, NULL, NULL, NULL),
(101, 'MA123', 'MJ DE LEON', NULL, 'MJDELEON@YAHOO.COM', NULL, '4th Year', 'A', NULL, '$2y$10$sQZ2aGSS3Gy9zpMYT6VkhemZORvilx1OaN2oft0IFVPGUOZvfUOGq', 'student', NULL, '', '', 'Bachelor of Technical-Vocational Teacher Education (BTVTED)', NULL, NULL, NULL, NULL, NULL, NULL),
(102, 'MA11111111', 'Joana Marie Cruz', NULL, 'joana.cruz@gmail.com', NULL, '2nd Year', 'A', NULL, '$2y$10$jJXBFhRsUF34c9nJJH8BG.z.cW4PNqST9JkMu9LRsrOmxKqZTpydy', 'student', NULL, '', '', 'Associate in Computer Technology (Ladderized to BSIS).', NULL, NULL, NULL, NULL, NULL, NULL),
(103, 'MA124', 'PauloVictoria', NULL, 'paulo.victoria@bpc.edu.ph', NULL, '4th Year', 'A', NULL, '$2y$10$FHXO7srP5kSHvF0ECfWuD.XdbR3bnWzgEHVJYZq/iRZyh62WUWj9u', 'student', NULL, '', '', 'Bachelor of Science in Information System (BSIS)', NULL, NULL, NULL, NULL, NULL, NULL),
(104, 'gabriel', 'Gabriel', NULL, 'gabriel@yahoo.com', NULL, '', '', NULL, '$2y$10$Yektjq0gqu9HaT16/ZRpa.G6Q5V.pgMSh8sFjCMQjWuoguVnT85JK', 'signatory', NULL, 'Program Head', 'Book - Keeping NC (III)', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(105, 'jj', 'Joana Marie Cruz', NULL, 'joana.cruz@bpc.edu.ph', NULL, '', '', NULL, '$2y$10$EtdQpA728ymayopLsSfBGOr8n5YhbDU/polH9cOSspZqTQChPywFe', 'signatory', NULL, 'Program Head', 'Associate in Computer Technology (Ladderized to BS', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(106, 'kk', 'kk', NULL, 'kk@gmail.com', NULL, '2nd Year', 'A', NULL, '$2y$10$osy7ckAmAOlAibozYHF9wujsXAN.XxAQg/PithQOH0V671Vbo0ECm', 'signatory', NULL, 'Class Adviser', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcement_reads`
--
ALTER TABLE `announcement_reads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `announcement_id` (`announcement_id`);

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clearance_requests`
--
ALTER TABLE `clearance_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clearance_requirements`
--
ALTER TABLE `clearance_requirements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `application_id` (`application_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course_name` (`course_name`);

--
-- Indexes for table `course_requirements`
--
ALTER TABLE `course_requirements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `requirement_id` (`requirement_id`),
  ADD KEY `idx_signatory_id` (`signatory_id`),
  ADD KEY `idx_document_type_id` (`document_type_id`);

--
-- Indexes for table `document_types`
--
ALTER TABLE `document_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `draft_requirements`
--
ALTER TABLE `draft_requirements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_draft_req_req` (`requirement_id`),
  ADD KEY `fk_draft_req_sig` (`signatory_id`),
  ADD KEY `fk_draft_req_doctype` (`document_type_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requirement_library`
--
ALTER TABLE `requirement_library`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_section` (`course_id`,`year`,`section_name`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `announcement_reads`
--
ALTER TABLE `announcement_reads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `clearance_requests`
--
ALTER TABLE `clearance_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clearance_requirements`
--
ALTER TABLE `clearance_requirements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `course_requirements`
--
ALTER TABLE `course_requirements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `document_types`
--
ALTER TABLE `document_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `draft_requirements`
--
ALTER TABLE `draft_requirements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `requirement_library`
--
ALTER TABLE `requirement_library`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcement_reads`
--
ALTER TABLE `announcement_reads`
  ADD CONSTRAINT `announcement_reads_ibfk_1` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`);

--
-- Constraints for table `clearance_requirements`
--
ALTER TABLE `clearance_requirements`
  ADD CONSTRAINT `clearance_requirements_ibfk_1` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `course_requirements`
--
ALTER TABLE `course_requirements`
  ADD CONSTRAINT `course_requirements_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `course_requirements_ibfk_2` FOREIGN KEY (`requirement_id`) REFERENCES `requirement_library` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cr_doctype` FOREIGN KEY (`document_type_id`) REFERENCES `document_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cr_signatory` FOREIGN KEY (`signatory_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `draft_requirements`
--
ALTER TABLE `draft_requirements`
  ADD CONSTRAINT `fk_draft_req_doctype` FOREIGN KEY (`document_type_id`) REFERENCES `document_types` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_draft_req_req` FOREIGN KEY (`requirement_id`) REFERENCES `requirement_library` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_draft_req_sig` FOREIGN KEY (`signatory_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
